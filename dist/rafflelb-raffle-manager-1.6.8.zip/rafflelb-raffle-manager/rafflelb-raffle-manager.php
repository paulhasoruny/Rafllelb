<?php
/**
 * Plugin Name: RaffleLB Raffle Manager
 * Description: A dedicated "Raffles" admin section (like WooCommerce Products) for creating, editing, and monitoring every raffle in one place. Reads and writes the same product fields, meta, and database tables as RaffleLB Draw Engine instead of duplicating its logic.
 * Version: 1.6.8
 * Author: RaffleLB
 */

if (!defined('ABSPATH')) exit;

final class RaffleLB_Raffle_Manager {
    const VERSION = '1.6.8';

    // Mirrors RaffleLB Draw Engine's own constants and table names so this
    // plugin reads/writes the exact same product meta and DB tables without
    // depending on load order between the two plugins.
    const META_ENABLED            = '_rafflelb_draw_enabled';
    const META_TOTAL              = '_rafflelb_total_entries';
    const META_DRAW_STATUS        = '_rafflelb_draw_status';
    const META_CLOSED_AT          = '_rafflelb_draw_closed_at';
    const META_WINNER_ENTRY_ID    = '_rafflelb_winner_entry_id';
    const META_WINNER_SELECTED_AT = '_rafflelb_winner_selected_at';
    const META_EARLY_CLOSED       = '_rafflelb_early_closed';
    const META_EARLY_CLOSE_REASON = '_rafflelb_early_close_reason';
    const META_EARLY_CLOSED_BY    = '_rafflelb_early_closed_by';
    const META_EARLY_CLOSE_CLAIMED = '_rafflelb_early_close_claimed';
    const META_BUY_NOW_ENABLED    = '_rafflelb_buy_now_enabled';
    const META_BUY_NOW_PRICE      = '_rafflelb_buy_now_price';

    // Delivery-type override read by RaffleLB Custom Checkout's Cash on
    // Delivery gate (rlcc_item_is_voucher_or_gift_card()). 'tangible' or
    // 'digital'; unset falls back to that plugin's own category-based check.
    const META_ITEM_TYPE = '_rafflelb_item_type';

    const ENTRY_TABLE   = 'rafflelb_entries';
    const RESULT_TABLE  = 'rafflelb_draw_results';
    const HOLD_TABLE    = 'rafflelb_holds';
    const HISTORY_TABLE = 'rafflelb_entry_history';

    const SLUG       = 'rafflelb-raffles';
    const SLUG_ADD   = 'rafflelb-raffle-add';
    const SLUG_RESET = 'rafflelb-raffle-reset';

    public static function init() {
        add_action('plugins_loaded', [__CLASS__, 'boot']);
    }

    public static function boot() {
        if (!class_exists('WooCommerce')) return;

        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_menu', [__CLASS__, 'hide_legacy_menu'], 999);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('admin_notices', [__CLASS__, 'missing_draw_engine_notice']);
        add_action('admin_post_rafflelb_rm_trash_raffle', [__CLASS__, 'handle_trash']);
        add_action('admin_post_rafflelb_rm_reset_winners', [__CLASS__, 'handle_reset_winners']);
        add_action('admin_post_rafflelb_rm_delete_test_orders', [__CLASS__, 'handle_delete_test_orders']);
        add_action('admin_post_rafflelb_rm_export_entries', [__CLASS__, 'handle_export_entries']);
    }

    public static function missing_draw_engine_notice() {
        if (class_exists('RaffleLB_Draw_Engine')) return;
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || strpos((string) $screen->id, 'rafflelb-raffle') === false) return;
        echo '<div class="notice notice-error"><p><strong>RaffleLB Raffle Manager</strong> needs the <strong>RaffleLB Draw Engine</strong> plugin active — it provides the entries, draw, and fulfillment engine this screen manages.</p></div>';
    }

    public static function admin_menu() {
        $list_hook = add_menu_page('Raffles', 'Raffles', 'manage_woocommerce', self::SLUG, [__CLASS__, 'render_list'], 'dashicons-tickets-alt', 56);
        add_submenu_page(self::SLUG, 'All Raffles', 'All Raffles', 'manage_woocommerce', self::SLUG, [__CLASS__, 'render_list']);
        $add_hook = add_submenu_page(self::SLUG, 'Add New Raffle', 'Add New Raffle', 'manage_woocommerce', self::SLUG_ADD, [__CLASS__, 'render_form']);
        add_submenu_page(self::SLUG, 'Reset / Cleanup', 'Reset / Cleanup', 'manage_woocommerce', self::SLUG_RESET, [__CLASS__, 'render_reset_page']);

        // Handled on load- (before any HTML is sent) so a save can safely redirect.
        add_action('load-' . $list_hook, [__CLASS__, 'maybe_handle_save']);
        add_action('load-' . $add_hook, [__CLASS__, 'maybe_handle_save']);
    }

    public static function hide_legacy_menu() {
        remove_submenu_page('woocommerce', 'rafflelb-entries');
    }

    public static function enqueue_assets($hook) {
        if (strpos((string) $hook, 'rafflelb-raffle') === false) return;
        wp_enqueue_media();
    }

    public static function render_list() {
        $action = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;

        if ($action === 'edit' && $id) { self::render_raffle_form($id); return; }
        if ($action === 'view' && $id) { self::render_monitor($id); return; }

        self::render_table();
    }

    public static function render_form() {
        self::render_raffle_form(0);
    }

    /* ---------------------------------------------------------------
     * Shared helpers (mirror the read-only logic in RaffleLB Draw Engine)
     * ------------------------------------------------------------- */

    private static function claimed($pid) {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d AND status='active'",
            $pid
        ));
    }

    private static function draw_status($pid) {
        $status = (string) get_post_meta($pid, self::META_DRAW_STATUS, true);
        if (in_array($status, ['ready_to_draw', 'winner_selected'], true)) return $status;

        $total = absint(get_post_meta($pid, self::META_TOTAL, true));
        if ($total > 0 && self::claimed($pid) >= $total) {
            update_post_meta($pid, self::META_DRAW_STATUS, 'ready_to_draw');
            return 'ready_to_draw';
        }
        return 'live';
    }

    /** Needs Attention: purely derived from data this plugin already reads —
     *  draw status, the existing early-close meta, and the existing per-row
     *  fulfillment status. No new database state and no Draw Engine change. */
    private static function needs_attention($pid, $status, $fulfillment = null) {
        if ($status === 'ready_to_draw') return true;
        if ($status !== 'winner_selected' && get_post_meta($pid, self::META_EARLY_CLOSED, true) === 'yes') return true;
        if ($status === 'winner_selected' && $fulfillment !== null && $fulfillment !== 'fulfilled') return true;
        return false;
    }

    /** Recent Activity: reads the existing rafflelb_entry_history table this
     *  plugin already queries elsewhere (Reset/Cleanup). Read-only; no new
     *  audit system, no write. */
    private static function recent_activity($pid, $limit = 8) {
        global $wpdb;
        $table = $wpdb->prefix . self::HISTORY_TABLE;
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) return [];
        return (array) $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE product_id=%d ORDER BY event_at DESC, id DESC LIMIT %d",
            $pid, $limit
        ));
    }

    private static function customer_name($user_id, $order) {
        if ($user_id) {
            $user = get_user_by('id', $user_id);
            if ($user) return $user->display_name;
        }
        if ($order) {
            $name = trim($order->get_formatted_billing_full_name());
            if ($name !== '') return $name;
        }
        return 'Guest';
    }

    /** Status pill: [label, modifier]. Presentational only — the status
     *  string itself still comes only from draw_status()/Draw Engine data. */
    private static function status_pill_parts($status) {
        $map = [
            'live'             => ['LIVE', 'live'],
            'ready_to_draw'    => ['READY TO DRAW', 'ready'],
            'winner_selected'  => ['WINNER SELECTED', 'winner'],
        ];
        return $map[$status] ?? [strtoupper(str_replace('_', ' ', (string) $status)), 'default'];
    }

    private static function status_badge($status) {
        [$label, $mod] = self::status_pill_parts($status);
        return '<span class="rlbrm-pill rlbrm-pill--' . esc_attr($mod) . '">' . esc_html($label) . '</span>';
    }

    /** Fulfillment pill: [label, modifier]. The stored value stays one of the
     *  4 real Draw Engine fulfillment states (pending/contacted/claimed/
     *  fulfilled) — only the displayed label groups "contacted"/"claimed"
     *  under one readable "In Progress" pill. No new state is written. */
    private static function fulfillment_pill_parts($status) {
        $map = [
            'pending'   => ['NOT STARTED', 'notstarted'],
            'contacted' => ['IN PROGRESS', 'progress'],
            'claimed'   => ['IN PROGRESS', 'progress'],
            'fulfilled' => ['FULFILLED', 'fulfilled'],
        ];
        return $map[$status] ?? ['NOT STARTED', 'notstarted'];
    }

    private static function fulfillment_badge($status) {
        [$label, $mod] = self::fulfillment_pill_parts($status);
        return '<span class="rlbrm-pill rlbrm-pill--' . esc_attr($mod) . '">' . esc_html($label) . '</span>';
    }

    private static function print_styles() {
        echo '<style>
        .rlbrm-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;margin:16px 0;box-shadow:0 1px 3px rgba(0,0,0,.04)}
        .rlbrm-border-amber{border-left:5px solid #dba617}
        .rlbrm-border-lime{border-left:5px solid #9cff00}
        .rlbrm-border-dark{border-left:5px solid #10130d}
        .rlbrm-bar{display:block;width:120px;height:6px;background:#eee;border-radius:99px;overflow:hidden;margin-bottom:4px}
        .rlbrm-bar span{display:block;height:100%;background:#9cff00}
        .rlbrm-image-field .rlbrm-image-preview img{display:block;max-width:150px;max-height:150px;padding:6px;border:1px solid #dcdcde;background:#fff;margin-bottom:8px;border-radius:4px}
        .rlbrm-tag-picker{margin-top:10px;max-width:640px}
        .rlbrm-tag-picker-label{display:block;margin-bottom:6px;color:#646970;font-size:12px}
        .rlbrm-tag-chip{margin:0 4px 4px 0}
        .rlbrm-stats{display:flex;flex-wrap:wrap;gap:28px;align-items:center}
        .rlbrm-stats > div{min-width:110px}
        /* v1.5.0 — operations UI only; existing forms and actions are preserved. */
        .rafflelb-rm{max-width:1500px;color:#f7f8f4;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.rafflelb-rm h1,.rafflelb-rm h2,.rafflelb-rm h3{color:#fff}.rafflelb-rm .widefat,.rafflelb-rm .rlbrm-card{background:#11130f;border-color:#2a3027;color:#e7ebe2;box-shadow:0 10px 26px rgba(0,0,0,.12)}.rafflelb-rm .widefat thead th,.rafflelb-rm .widefat td{border-color:#2a3027;color:inherit}.rafflelb-rm .widefat thead th{background:#171a15;color:#9ba496;font-size:11px;text-transform:uppercase;letter-spacing:.07em}.rafflelb-rm .widefat tr:hover td{background:#171a15}.rafflelb-rm .subsubsub{float:none;display:flex;flex-wrap:wrap;gap:8px;margin:16px 0}.rafflelb-rm .subsubsub li{margin:0}.rafflelb-rm .subsubsub a{display:inline-flex;padding:8px 11px;border:1px solid #2a3027;border-radius:7px;background:#11130f;color:#c9d0c5}.rafflelb-rm .subsubsub a.current{background:#baff00;border-color:#baff00;color:#090a08;font-weight:700}.rafflelb-rm input[type=search],.rafflelb-rm input[type=text],.rafflelb-rm select,.rafflelb-rm textarea{background:#0d110d!important;border-color:#364031!important;color:#fff!important}.rafflelb-rm .button-primary{background:#baff00!important;border-color:#baff00!important;color:#090a08!important}.rlbrm-card{background:#11130f}.rlbrm-bar{background:#293128}.rlbrm-bar span{background:#baff00}.rlbrm-stats{gap:18px}.rlbrm-stats>div{padding:10px;border-left:1px solid #2a3027}.rlbrm-stats>div:first-child{border-left:0}@media(max-width:782px){.rafflelb-rm .widefat{display:block;overflow-x:auto;white-space:nowrap}.rafflelb-rm .subsubsub{gap:6px}.rlbrm-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}.rlbrm-stats>div{border-left:0;border-top:1px solid #2a3027}.rlbrm-stats>div:first-child{border-top:0}}
        .rlbrm-workspace-tabs{display:flex;flex-wrap:wrap;gap:6px;margin:18px 0}.rlbrm-workspace-tabs button{padding:9px 12px;border:1px solid #2a3027;border-radius:8px;background:#11130f;color:#c9d0c5;cursor:pointer}.rlbrm-workspace-tabs button.is-active{background:#baff00;border-color:#baff00;color:#090a08;font-weight:700}.rlbrm-workspace-panel{display:none}.rlbrm-workspace-panel.is-active{display:block}.rlbrm-workspace-panel .rlbrm-card{margin-top:0}.rlbrm-overview-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}.rlbrm-overview-head h2{margin:0 0 5px}.rlbrm-overview-head p{margin:0;color:#9ba496}.rlbrm-overview-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.rlbrm-overview-grid>div{padding:14px;border:1px solid #2a3027;border-radius:10px;background:#0d110d}.rlbrm-overview-grid span:first-child{display:block;color:#9ba496;font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}.rlbrm-overview-grid strong{display:block;color:#fff;font-size:18px}.rlbrm-overview-grid small{display:block;color:#7f887a;margin-top:4px}.rlbrm-overview-grid .rlbrm-bar{margin-top:9px;width:100%}.rlbrm-fulfillment-stepper{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:14px 0 20px}.rlbrm-fulfillment-step{padding:12px;border:1px solid #2a3027;border-radius:10px;background:#0d110d;color:#8f988a}.rlbrm-fulfillment-step span{display:inline-block;width:9px;height:9px;border-radius:50%;background:#495044;margin-right:7px}.rlbrm-fulfillment-step.is-current{border-color:#baff00;color:#fff}.rlbrm-fulfillment-step.is-current span,.rlbrm-fulfillment-step.is-complete span{background:#baff00}.rlbrm-fulfillment-step.is-complete{color:#dfe8d8}.rlbrm-audit-hash{display:block;max-width:100%;white-space:normal;overflow-wrap:anywhere;color:#dfe8d8}.rlbrm-fulfillment-lock{margin:10px 0;padding:10px 12px;border:1px solid #5a431b;border-radius:8px;background:#21190d}@media(max-width:900px){.rlbrm-overview-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.rlbrm-fulfillment-stepper{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:600px){.rlbrm-overview-grid,.rlbrm-fulfillment-stepper{grid-template-columns:1fr}.rlbrm-overview-head{flex-direction:column}}
        .rlbrm-list-header{display:flex;justify-content:space-between;align-items:center;gap:20px;margin:20px 0}.rlbrm-list-header h1{margin:0}.rlbrm-list-header p{color:#9ba496}.rlbrm-kicker{font-size:10px!important;font-weight:800;letter-spacing:.12em;color:#baff00!important}.rlbrm-list-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}.rlbrm-list-tabs a{padding:8px 11px;border:1px solid #2a3027;border-radius:8px;background:#11130f;color:#c9d0c5;text-decoration:none}.rlbrm-list-tabs a.current{background:#baff00;color:#090a08;border-color:#baff00}.rlbrm-list-toolbar{display:flex;gap:8px;align-items:center;margin:12px 0}.rlbrm-list-wrap{overflow:auto}.rlbrm-raffle-cell{display:flex;gap:12px;align-items:center}.rlbrm-raffle-cell small{display:block;color:#9ba496;margin-top:4px}.rlbrm-thumb{width:60px;height:60px;object-fit:cover;border-radius:9px}.rlbrm-table th:nth-child(4),.rlbrm-table td:nth-child(4){min-width:150px}.rlbrm-table th:nth-child(5),.rlbrm-table td:nth-child(5){min-width:120px}.rlbrm-table th:nth-child(3){min-width:170px}.rlbrm-table th:nth-child(6),.rlbrm-table td:nth-child(6){min-width:150px}.rlbrm-row-ready_to_draw td{background:rgba(186,255,0,.04)}@media(max-width:782px){.rlbrm-list-header{align-items:flex-start;flex-direction:column}.rlbrm-list-toolbar{flex-wrap:wrap}.rlbrm-table{min-width:970px}}
        /* v1.6.7 — Operations UI/UX redesign. Purely presentational; no business logic. */
        .rlbrm-pill{display:inline-flex;align-items:center;padding:4px 9px;border:1px solid #2a3027;border-radius:999px;background:#12160f;color:#cdd6c5;font-size:10px;font-weight:750;letter-spacing:.05em;text-transform:uppercase;white-space:nowrap}
        .rlbrm-pill--live{border-color:#baff00;background:rgba(186,255,0,.14);color:#e6ffab}
        .rlbrm-pill--ready{border-color:#dba617;background:rgba(219,166,23,.14);color:#ffd98a}
        .rlbrm-pill--winner{border-color:#f4f0d8;background:#1c1f14;color:#fff6c9}
        .rlbrm-pill--default,.rlbrm-pill--notstarted{color:#9ba496}
        .rlbrm-pill--progress{border-color:#dba617;color:#ffd98a}
        .rlbrm-pill--fulfilled{border-color:#3c6e00;background:rgba(60,110,0,.16);color:#c7e79b}
        .rlbrm-pill--active,.rlbrm-pill--paid{border-color:#3c6e00;background:rgba(60,110,0,.14);color:#c7e79b}
        .rlbrm-pill--void,.rlbrm-pill--cancelled{border-color:#5a2a22;background:rgba(180,35,24,.10);color:#e3a89c}
        .rlbrm-pill--pending{border-color:#dba617;color:#ffd98a}
        .rlbrm-raffle-cell{display:flex;gap:12px;align-items:flex-start}
        .rlbrm-thumb-wrap{flex:0 0 auto}
        .rlbrm-thumb{width:56px;height:56px;object-fit:cover;border-radius:9px;border:1px solid #232920}
        .rlbrm-prize-main{min-width:0}
        .rlbrm-prize-name{display:block;color:#fff;font-size:14px;font-weight:650;line-height:1.35}
        .rlbrm-prize-name a{color:inherit;text-decoration:none}
        .rlbrm-prize-name a:hover{text-decoration:underline}
        .rlbrm-prize-sku{display:block;margin-top:3px;color:#818c7e;font-size:11.5px;font-weight:500}
        .rlbrm-attention-flag{display:inline-block;margin-top:6px;padding:2px 7px;border:1px solid #dba617;border-radius:999px;color:#ffd98a;font-size:9px;font-weight:800;letter-spacing:.05em;text-transform:uppercase}
        .rlbrm-row-attention td:first-child{box-shadow:inset 3px 0 0 #dba617}
        .rlbrm-cell-label{display:block;color:#818c7e;font-size:9.5px;font-weight:700;letter-spacing:.07em;text-transform:uppercase}
        .rlbrm-cell-value{display:block;margin-top:3px;color:#fff;font-size:14.5px;font-weight:700}
        .rlbrm-cell-sub{display:block;margin-top:4px;color:#9ba496;font-size:11.5px}
        .rlbrm-entry-cell .rlbrm-bar{margin-top:6px;width:140px}
        .rlbrm-winner-cell strong{display:block;color:#fff;font-size:13.5px;font-weight:650}
        .rlbrm-winner-flag{display:block;margin-bottom:3px;color:#ffd98a;font-size:9.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}
        .rlbrm-winner-cell small{display:block;margin-top:3px;color:#818c7e;font-size:11px}
        .rlbrm-no-winner{color:#6f786a;font-size:12.5px;font-style:normal}
        .rlbrm-actions-cell{display:flex;flex-direction:column;align-items:flex-start;gap:6px}
        .rlbrm-action{text-decoration:none}
        .rlbrm-action--primary{color:#baff00;font-size:12.5px;font-weight:750}
        .rlbrm-action--secondary{color:#c9d0c5;font-size:12px;font-weight:550}
        .rlbrm-action--tertiary{color:#7f887a;font-size:11.5px;font-weight:500}
        .rlbrm-action:hover{text-decoration:underline}
        .rlbrm-list-tabs a.rlbrm-tab-attention{border-color:#dba617;color:#ffd98a}
        .rlbrm-list-tabs a.rlbrm-tab-attention.current{background:#dba617;border-color:#dba617;color:#1c1400}
        .rlbrm-muted{color:#9ba496}
        .rlbrm-section-head{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:14px}
        .rlbrm-section-head h2{margin:0}
        .rlbrm-subtoolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:14px}
        .rlbrm-inline-tabs{display:flex;gap:6px;flex-wrap:wrap}
        .rlbrm-inline-tabs a{padding:6px 10px;border:1px solid #2a3027;border-radius:7px;background:#11130f;color:#c9d0c5;text-decoration:none;font-size:12px}
        .rlbrm-inline-tabs a.current{background:#baff00;border-color:#baff00;color:#090a08;font-weight:700}
        .rlbrm-inline-search{display:flex;gap:8px;flex-wrap:wrap}
        .rlbrm-metric-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}
        .rlbrm-metric-grid>div{padding:14px;border:1px solid #2a3027;border-radius:10px;background:#0d110d}
        .rlbrm-metric-grid span:first-child{display:block;color:#9ba496;font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
        .rlbrm-metric-grid strong{display:block;color:#fff;font-size:18px}
        .rlbrm-metric-grid small{display:block;color:#7f887a;margin-top:4px}
        .rlbrm-overview-sections{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:6px}
        .rlbrm-overview-section{padding:16px;border:1px solid #2a3027;border-radius:10px;background:#0d110d}
        .rlbrm-overview-section h3{margin:0 0 12px;color:#fff;font-size:13px;text-transform:uppercase;letter-spacing:.06em}
        .rlbrm-overview-section dl{margin:0}
        .rlbrm-overview-section dl div{display:flex;justify-content:space-between;gap:10px;padding:7px 0;border-top:1px solid #202620}
        .rlbrm-overview-section dl div:first-child{border-top:0}
        .rlbrm-overview-section dt{color:#9ba496;font-size:12px}
        .rlbrm-overview-section dd{margin:0;color:#fff;font-size:12.5px;text-align:right}
        .rlbrm-overview-activity{margin-top:14px}
        .rlbrm-activity-list{margin:0;padding:0;list-style:none}
        .rlbrm-activity-list li{padding:9px 0;border-top:1px solid #202620;color:#dfe8d8;font-size:12.5px}
        .rlbrm-activity-list li:first-child{border-top:0}
        .rlbrm-activity-event{color:#fff;font-weight:650}
        .rlbrm-activity-list small{display:block;margin-top:3px;color:#7f887a;font-size:11px}
        @media(max-width:1100px){.rlbrm-metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.rlbrm-overview-sections{grid-template-columns:1fr}}
        @media(max-width:782px){.rlbrm-metric-grid{grid-template-columns:1fr}.rlbrm-subtoolbar{flex-direction:column;align-items:stretch}.rlbrm-inline-search{flex-wrap:wrap}.rlbrm-table{min-width:1080px}}
        </style>';
    }

    /* ---------------------------------------------------------------
     * List / table view
     * ------------------------------------------------------------- */

    private static function render_table() {
        $status_filter = isset($_GET['rm_status']) ? sanitize_key(wp_unslash($_GET['rm_status'])) : '';
        $search = isset($_GET['rm_s']) ? sanitize_text_field(wp_unslash($_GET['rm_s'])) : '';
        $paged = max(1, isset($_GET['rm_paged']) ? absint($_GET['rm_paged']) : 1);
        $per_page = 20;

        $args = [
            'post_type'      => 'product',
            'post_status'    => ['publish', 'private', 'draft'],
            'posts_per_page' => -1,
            'meta_key'       => self::META_ENABLED,
            'meta_value'     => 'yes',
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ];
        if ($search !== '') $args['s'] = $search;
        $ids = get_posts($args);

        global $wpdb;
        $rows = [];
        $counts = ['live' => 0, 'ready_to_draw' => 0, 'winner_selected' => 0, 'needs_fulfillment' => 0, 'fulfilled' => 0, 'needs_attention' => 0];
        foreach ($ids as $pid) {
            $status = self::draw_status($pid);
            $counts[$status] = ($counts[$status] ?? 0) + 1;

            $row = [
                'id'     => $pid,
                'status' => $status,
                'total'  => absint(get_post_meta($pid, self::META_TOTAL, true)),
                'claimed'=> self::claimed($pid),
            ];

            if ($status === 'winner_selected') {
                $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}" . self::RESULT_TABLE . " WHERE product_id=%d LIMIT 1", $pid));
                if ($result) {
                    $order = wc_get_order(absint($result->order_id));
                    $row['winner'] = self::customer_name(absint($result->user_id), $order);
                    $row['fulfillment'] = !empty($result->fulfillment_status) ? $result->fulfillment_status : 'pending';
                    $row['entry_number'] = $result->entry_number;
                    $composite = $row['fulfillment'] === 'fulfilled' ? 'fulfilled' : 'needs_fulfillment';
                    $counts[$composite]++;
                }
            }

            $row['needs_attention'] = self::needs_attention($pid, $status, $row['fulfillment'] ?? null);
            if ($row['needs_attention']) $counts['needs_attention']++;

            $matches_filter = $status_filter === ''
                || $status === $status_filter
                || ($status_filter === 'needs_fulfillment' && isset($row['fulfillment']) && $row['fulfillment'] !== 'fulfilled')
                || ($status_filter === 'fulfilled' && isset($row['fulfillment']) && $row['fulfillment'] === 'fulfilled')
                || ($status_filter === 'needs_attention' && $row['needs_attention']);
            if (!$matches_filter) continue;

            $rows[] = $row;
        }

        $total_rows = count($rows);
        $total_pages = max(1, (int) ceil($total_rows / $per_page));
        $paged = min($paged, $total_pages);
        $page_rows = array_slice($rows, ($paged - 1) * $per_page, $per_page);

        $base_url = admin_url('admin.php?page=' . self::SLUG);

        echo '<div class="wrap rafflelb-rm">';
        self::print_styles();

        $notice = isset($_GET['rlbrm']) ? sanitize_key(wp_unslash($_GET['rlbrm'])) : '';
        if ($notice === 'saved') echo '<div class="notice notice-success is-dismissible"><p>Raffle saved.</p></div>';
        if ($notice === 'trashed') echo '<div class="notice notice-success is-dismissible"><p>Raffle moved to trash.</p></div>';

        echo '<header class="rlbrm-list-header"><div><p class="rlbrm-kicker">RAFFLELB / OPERATIONS</p><h1>Raffle Operations</h1><p>Manage live raffles, draws, winners and fulfillment. ' . esc_html(count($ids)) . ' total raffles.</p></div><a href="' . esc_url(admin_url('admin.php?page=' . self::SLUG_ADD)) . '" class="button button-primary">+ Create Raffle</a></header>';

        $tabs = [
            ''                   => 'All ' . count($ids),
            'live'               => 'Live ' . $counts['live'],
            'ready_to_draw'      => 'Ready to Draw ' . $counts['ready_to_draw'],
            'winner_selected'    => 'Winner Selected ' . $counts['winner_selected'],
            'needs_fulfillment'  => 'Needs Fulfillment ' . $counts['needs_fulfillment'],
            'fulfilled'          => 'Fulfilled ' . $counts['fulfilled'],
            'needs_attention'    => 'Needs Attention ' . $counts['needs_attention'],
        ];
        $links = [];
        foreach ($tabs as $key => $label) {
            $url = $key === '' ? $base_url : add_query_arg('rm_status', $key, $base_url);
            $classes = [];
            if ($status_filter === $key) $classes[] = 'current';
            if ($key === 'needs_attention') $classes[] = 'rlbrm-tab-attention';
            $class = $classes ? ' class="' . esc_attr(implode(' ', $classes)) . '"' : '';
            $links[] = '<a href="' . esc_url($url) . '"' . $class . '>' . esc_html($label) . '</a>';
        }
        echo '<nav class="rlbrm-list-tabs" aria-label="Raffle states">' . implode('', $links) . '</nav>';

        echo '<form method="get" class="rlbrm-list-toolbar">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '">';
        if ($status_filter !== '') echo '<input type="hidden" name="rm_status" value="' . esc_attr($status_filter) . '">';
        echo '<input type="search" name="rm_s" value="' . esc_attr($search) . '" placeholder="Search raffles…">';
        echo '<button type="submit" class="button">Search</button>';
        if ($search !== '') {
            $clear = $status_filter !== '' ? add_query_arg('rm_status', $status_filter, $base_url) : $base_url;
            echo '<a class="button" href="' . esc_url($clear) . '">Clear</a>';
        }
        echo '</form>';

        if (!$page_rows) {
            if ($search !== '' || $status_filter !== '') {
                echo '<p>No raffles match this search/filter.</p>';
            } else {
                echo '<p>No raffles yet. <a href="' . esc_url(admin_url('admin.php?page=' . self::SLUG_ADD)) . '">Create your first raffle.</a></p>';
            }
        } else {
            echo '<div class="rlbrm-list-wrap"><table class="widefat rlbrm-table"><thead><tr><th>Prize</th><th>Status</th><th>Entry / Capacity</th><th>Winner</th><th>Fulfillment</th><th>Action</th></tr></thead><tbody>';
            foreach ($page_rows as $row) {
                $pid = $row['id'];
                $view_url = add_query_arg(['page' => self::SLUG, 'action' => 'view', 'id' => $pid], admin_url('admin.php'));
                $edit_url = add_query_arg(['page' => self::SLUG, 'action' => 'edit', 'id' => $pid], admin_url('admin.php'));
                $pct = $row['total'] > 0 ? min(100, round(($row['claimed'] / $row['total']) * 100)) : 0;
                $price = (float) get_post_meta($pid, '_regular_price', true);
                $sku = get_post_meta($pid, '_sku', true);
                $row_classes = 'rlbrm-row-' . $row['status'] . ($row['needs_attention'] ? ' rlbrm-row-attention' : '');

                echo '<tr class="' . esc_attr($row_classes) . '">';

                echo '<td class="rlbrm-raffle-cell"><span class="rlbrm-thumb-wrap">' . get_the_post_thumbnail($pid, [56, 56], ['class' => 'rlbrm-thumb']) . '</span>'
                    . '<div class="rlbrm-prize-main"><strong class="rlbrm-prize-name"><a href="' . esc_url($view_url) . '">' . esc_html(get_the_title($pid)) . '</a></strong>'
                    . '<small class="rlbrm-prize-sku">' . esc_html($sku !== '' ? 'SKU ' . $sku : 'ID ' . $pid) . '</small></div></td>';

                echo '<td>' . self::status_badge($row['status']) . ($row['needs_attention'] ? '<span class="rlbrm-attention-flag" title="Needs admin action">Needs attention</span>' : '') . '</td>';

                echo '<td><div class="rlbrm-entry-cell"><span class="rlbrm-cell-label">Entry price</span><strong class="rlbrm-cell-value">' . wp_kses_post(wc_price($price)) . '</strong>'
                    . '<span class="rlbrm-cell-sub">' . esc_html($row['claimed']) . ' / ' . esc_html($row['total']) . ' claimed · ' . esc_html($pct) . '%</span>'
                    . '<span class="rlbrm-bar"><span style="width:' . esc_attr($pct) . '%"></span></span></div></td>';

                if (isset($row['winner'])) {
                    echo '<td><div class="rlbrm-winner-cell"><span class="rlbrm-winner-flag">Winner selected</span><strong>' . esc_html($row['winner']) . '</strong>'
                        . '<small>Entry #' . esc_html(str_pad((string) $row['entry_number'], 3, '0', STR_PAD_LEFT)) . '</small></div></td>';
                } else {
                    echo '<td><span class="rlbrm-no-winner">No winner yet</span></td>';
                }

                echo '<td>' . (isset($row['fulfillment']) ? self::fulfillment_badge($row['fulfillment']) : '<span class="rlbrm-no-winner">—</span>') . '</td>';

                echo '<td class="rlbrm-actions-cell"><a class="rlbrm-action rlbrm-action--primary" href="' . esc_url($view_url) . '">Manage →</a>';
                if ($row['status'] === 'ready_to_draw') {
                    echo '<a class="rlbrm-action rlbrm-action--secondary" href="' . esc_url($view_url . '#draw') . '">Draw Winner</a>';
                }
                if (isset($row['fulfillment']) && $row['fulfillment'] !== 'fulfilled') {
                    echo '<a class="rlbrm-action rlbrm-action--secondary" href="' . esc_url($view_url . '#fulfillment') . '">Manage Fulfillment</a>';
                }
                echo '<a class="rlbrm-action rlbrm-action--tertiary" href="' . esc_url($edit_url) . '">Edit</a></td>';

                echo '</tr>';
            }
            echo '</tbody></table></div>';

            if ($total_pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                for ($p = 1; $p <= $total_pages; $p++) {
                    $url = add_query_arg(array_filter(['rm_status' => $status_filter, 'rm_s' => $search, 'rm_paged' => $p]), $base_url);
                    echo $p === $paged
                        ? '<strong style="padding:4px 9px;border:1px solid #111;border-radius:4px;margin-right:4px">' . esc_html($p) . '</strong>'
                        : '<a class="button" style="margin-right:4px" href="' . esc_url($url) . '">' . esc_html($p) . '</a>';
                }
                echo '</div></div>';
            }
        }

        echo '</div>';
    }

    /* ---------------------------------------------------------------
     * Add / Edit form
     * ------------------------------------------------------------- */

    public static function maybe_handle_save() {
        if (empty($_POST['rafflelb_rm_save'])) return;
        check_admin_referer('rafflelb_rm_save_raffle');

        $id = isset($_POST['raffle_id']) ? absint($_POST['raffle_id']) : 0;
        $result = self::save_raffle($id);

        if (is_wp_error($result)) {
            $back = $id
                ? admin_url('admin.php?page=' . self::SLUG . '&action=edit&id=' . $id)
                : admin_url('admin.php?page=' . self::SLUG_ADD);
            wp_safe_redirect(add_query_arg('rlbrm_error', rawurlencode($result->get_error_message()), $back));
            exit;
        }

        wp_safe_redirect(admin_url('admin.php?page=' . self::SLUG . '&action=view&id=' . $result . '&rlbrm=saved'));
        exit;
    }

    private static function save_raffle($id = 0) {
        if (!current_user_can('manage_woocommerce')) {
            return new WP_Error('cap', 'You are not allowed to manage raffles.');
        }

        $title = isset($_POST['raffle_title']) ? sanitize_text_field(wp_unslash($_POST['raffle_title'])) : '';
        if ($title === '') return new WP_Error('title', 'A raffle title is required.');

        $price = isset($_POST['raffle_price']) ? wc_format_decimal(wp_unslash($_POST['raffle_price'])) : '';
        if ($price === '' || (float) $price <= 0) return new WP_Error('price', 'A raffle price greater than 0 is required.');

        $total = isset($_POST['raffle_total_entries']) ? absint(wp_unslash($_POST['raffle_total_entries'])) : 0;
        if ($total < 1) return new WP_Error('total', 'Total raffle entries must be at least 1.');

        $description = isset($_POST['raffle_description']) ? wp_kses_post(wp_unslash($_POST['raffle_description'])) : '';
        $status = (isset($_POST['raffle_status']) && $_POST['raffle_status'] === 'draft') ? 'draft' : 'publish';
        $category = isset($_POST['raffle_category']) ? absint(wp_unslash($_POST['raffle_category'])) : 0;
        $buy_now_enabled = !empty($_POST['raffle_buy_now_enabled']);
        $buy_now_price = isset($_POST['raffle_buy_now_price']) ? wc_format_decimal(wp_unslash($_POST['raffle_buy_now_price'])) : '';
        $featured_id = isset($_POST['raffle_image']) ? absint(wp_unslash($_POST['raffle_image'])) : 0;
        $tags_raw = isset($_POST['raffle_tags']) ? sanitize_text_field(wp_unslash($_POST['raffle_tags'])) : '';
        $tag_names = array_values(array_filter(array_map('trim', explode(',', $tags_raw)), 'strlen'));
        $item_type = (isset($_POST['raffle_item_type']) && $_POST['raffle_item_type'] === 'digital') ? 'digital' : 'tangible';

        if ($id) {
            if (!current_user_can('edit_post', $id)) return new WP_Error('cap', 'You are not allowed to edit this raffle.');
            $product = wc_get_product($id);
            if (!$product) return new WP_Error('missing', 'Raffle product not found.');
            if (!$product->is_type('simple')) return new WP_Error('type', 'This product is not a simple product and cannot be saved from this screen.');
        } else {
            $product = new WC_Product_Simple();
        }

        $product->set_name($title);
        $product->set_description($description);
        $product->set_status($status);
        $product->set_regular_price($price);
        $product->set_price($price);
        $product->set_virtual(true);
        $product->set_manage_stock(true);
        $product->set_backorders('no');
        $product->set_sold_individually(false);
        $product->set_stock_quantity($total);
        $product->set_stock_status($total > 0 ? 'instock' : 'outofstock');
        $product->set_image_id(($featured_id && wp_attachment_is_image($featured_id)) ? $featured_id : 0);

        $product_id = $product->save();
        if (!$product_id) return new WP_Error('save', 'The raffle could not be saved.');

        wp_set_object_terms($product_id, $category ? [$category] : [], 'product_cat');
        wp_set_object_terms($product_id, $tag_names, 'product_tag');

        update_post_meta($product_id, self::META_ENABLED, 'yes');
        update_post_meta($product_id, self::META_TOTAL, $total);
        update_post_meta($product_id, self::META_ITEM_TYPE, $item_type);
        update_post_meta($product_id, self::META_BUY_NOW_ENABLED, $buy_now_enabled ? 'yes' : 'no');
        if ($buy_now_enabled && $buy_now_price !== '' && (float) $buy_now_price > 0) {
            update_post_meta($product_id, self::META_BUY_NOW_PRICE, $buy_now_price);
        } else {
            delete_post_meta($product_id, self::META_BUY_NOW_PRICE);
        }

        return $product_id;
    }

    private static function render_raffle_form($id = 0) {
        $editing = $id > 0;
        $product = null;

        echo '<div class="wrap rafflelb-rm">';
        self::print_styles();
        echo '<h1 class="wp-heading-inline">' . ($editing ? 'Edit Raffle' : 'Add New Raffle') . '</h1> ';
        echo '<a href="' . esc_url(admin_url('admin.php?page=' . self::SLUG)) . '" class="page-title-action">Back to All Raffles</a>';
        echo '<hr class="wp-header-end">';

        if ($editing) {
            $product = wc_get_product($id);
            if (!$product) {
                echo '<div class="notice notice-error"><p>Raffle not found.</p></div></div>';
                return;
            }
            if (!$product->is_type('simple')) {
                echo '<div class="notice notice-error"><p>This raffle is not a simple product and can\'t be edited here. <a href="' . esc_url(get_edit_post_link($id)) . '">Edit it in the standard WooCommerce screen instead.</a></p></div></div>';
                return;
            }
        }

        $error = isset($_GET['rlbrm_error']) ? sanitize_text_field(wp_unslash($_GET['rlbrm_error'])) : '';
        if ($error !== '') echo '<div class="notice notice-error"><p>' . esc_html($error) . '</p></div>';

        if ($editing && self::claimed($id) > 0) {
            echo '<div class="notice notice-warning"><p>This raffle already has paid entries. Changing the raffle price or total entries here does not affect entries already sold.</p></div>';
        }

        $title = $editing ? $product->get_name() : '';
        $description = $editing ? $product->get_description() : '';
        $price = $editing ? get_post_meta($id, '_regular_price', true) : '';
        $total = $editing ? absint(get_post_meta($id, self::META_TOTAL, true)) : '';
        $buy_now_enabled = $editing && get_post_meta($id, self::META_BUY_NOW_ENABLED, true) === 'yes';
        $buy_now_price = $editing ? get_post_meta($id, self::META_BUY_NOW_PRICE, true) : '';
        $featured_id = $editing ? absint($product->get_image_id()) : 0;
        $post_status = $editing ? $product->get_status() : 'publish';
        $current_cats = $editing ? wp_get_post_terms($id, 'product_cat', ['fields' => 'ids']) : [];
        $current_cat = !empty($current_cats) ? (int) $current_cats[0] : 0;
        $current_tags = $editing ? implode(', ', wp_get_post_terms($id, 'product_tag', ['fields' => 'names'])) : '';
        $item_type = $editing ? get_post_meta($id, self::META_ITEM_TYPE, true) : 'tangible';
        if (!in_array($item_type, ['tangible', 'digital'], true)) $item_type = 'tangible';

        $form_action = $editing
            ? admin_url('admin.php?page=' . self::SLUG . '&action=edit&id=' . $id)
            : admin_url('admin.php?page=' . self::SLUG_ADD);

        echo '<form method="post" action="' . esc_url($form_action) . '" enctype="multipart/form-data">';
        wp_nonce_field('rafflelb_rm_save_raffle');
        echo '<input type="hidden" name="rafflelb_rm_save" value="1">';
        echo '<input type="hidden" name="raffle_id" value="' . esc_attr($id) . '">';

        echo '<div class="rlbrm-card"><table class="form-table"><tbody>';

        echo '<tr><th><label for="raffle_title">Title <span style="color:#b42318">*</span></label></th><td><input type="text" id="raffle_title" name="raffle_title" value="' . esc_attr($title) . '" class="large-text" required></td></tr>';

        echo '<tr><th><label for="raffle_description">Description</label></th><td><textarea id="raffle_description" name="raffle_description" rows="6" class="large-text">' . esc_textarea($description) . '</textarea></td></tr>';

        echo '<tr><th>Image</th><td>' . self::image_uploader_field('raffle_image', $featured_id, 'Choose Image') . '</td></tr>';

        echo '<tr><th><label for="raffle_category">Category</label></th><td>';
        wp_dropdown_categories([
            'taxonomy'          => 'product_cat',
            'name'              => 'raffle_category',
            'id'                => 'raffle_category',
            'hierarchical'      => true,
            'show_option_none'  => '— Select category —',
            'option_none_value' => '0',
            'selected'          => $current_cat,
            'hide_empty'        => false,
        ]);
        echo '</td></tr>';

        echo '<tr><th><label for="raffle_tags">Tags</label></th><td>';
        echo '<input type="text" id="raffle_tags" name="raffle_tags" value="' . esc_attr($current_tags) . '" class="large-text">';
        echo '<p class="description">Comma-separated. Click an existing tag below to add or remove it.</p>';
        echo self::tag_picker();
        echo '</td></tr>';

        echo '<tr><th><label for="raffle_price">Raffle Price ($) <span style="color:#b42318">*</span></label></th><td><input type="number" step="0.01" min="0.01" id="raffle_price" name="raffle_price" value="' . esc_attr($price) . '" class="regular-text" required><p class="description">This sets the WooCommerce Regular Price — the price of one raffle entry.</p></td></tr>';

        echo '<tr><th><label for="raffle_total_entries">Total Raffle Entries <span style="color:#b42318">*</span></label></th><td><input type="number" step="1" min="1" id="raffle_total_entries" name="raffle_total_entries" value="' . esc_attr($total) . '" class="regular-text" required><p class="description">Also sets stock/availability, same as the WooCommerce product screen.</p></td></tr>';

        echo '<tr><th>Buy It Now</th><td>';
        echo '<label><input type="checkbox" name="raffle_buy_now_enabled" value="1" ' . checked($buy_now_enabled, true, false) . '> Enable direct purchase (Buy It Now)</label><br><br>';
        echo '<label for="raffle_buy_now_price">Retail Price ($)</label><br>';
        echo '<input type="number" step="0.01" min="0" id="raffle_buy_now_price" name="raffle_buy_now_price" value="' . esc_attr($buy_now_price) . '" class="regular-text">';
        echo '<p class="description">The price of the item if bought directly instead of raffled. Also shown as the "Retail Price" on the storefront when Buy It Now is enabled.</p>';
        echo '</td></tr>';

        echo '<tr><th>Delivery Type</th><td>';
        echo '<label><input type="radio" name="raffle_item_type" value="tangible" ' . checked($item_type, 'tangible', false) . '> Tangible / physical item</label><br>';
        echo '<label><input type="radio" name="raffle_item_type" value="digital" ' . checked($item_type, 'digital', false) . '> Digital (voucher / gift card)</label>';
        echo '<p class="description">Physical items are eligible for Cash on Delivery at checkout. Digital items are not, and are fulfilled by WhatsApp/email instead.</p>';
        echo '</td></tr>';

        echo '<tr><th><label for="raffle_status">Status</label></th><td><select id="raffle_status" name="raffle_status">';
        echo '<option value="publish" ' . selected($post_status, 'publish', false) . '>Published</option>';
        echo '<option value="draft" ' . selected($post_status, 'draft', false) . '>Draft</option>';
        echo '</select></td></tr>';

        echo '</tbody></table></div>';

        submit_button($editing ? 'Update Raffle' : 'Create Raffle');
        echo '</form>';

        self::print_image_uploader_script();
        echo '</div>';
    }

    private static function image_uploader_field($name, $attachment_id, $button_label) {
        $url = $attachment_id ? wp_get_attachment_image_url($attachment_id, 'medium') : '';
        $html = '<div class="rlbrm-image-field" data-field="' . esc_attr($name) . '">';
        $html .= '<input type="hidden" class="rlbrm-image-id" name="' . esc_attr($name) . '" value="' . esc_attr($attachment_id) . '">';
        $html .= '<span class="rlbrm-image-preview">' . ($url ? '<img src="' . esc_url($url) . '" alt="">' : '') . '</span>';
        $html .= '<div><button type="button" class="button rlbrm-image-upload">' . esc_html($attachment_id ? 'Change Image' : $button_label) . '</button> ';
        $html .= '<button type="button" class="button rlbrm-image-remove" style="' . ($attachment_id ? '' : 'display:none') . '">Remove</button></div>';
        $html .= '</div>';
        return $html;
    }

    private static function tag_picker() {
        $terms = get_terms(['taxonomy' => 'product_tag', 'hide_empty' => false, 'orderby' => 'name']);
        if (is_wp_error($terms) || !$terms) return '';

        $html = '<div class="rlbrm-tag-picker"><span class="rlbrm-tag-picker-label">Existing tags:</span> ';
        foreach ($terms as $term) {
            $html .= '<button type="button" class="button button-small rlbrm-tag-chip" data-tag="' . esc_attr($term->name) . '">' . esc_html($term->name) . '</button> ';
        }
        $html .= '</div>';
        return $html;
    }

    private static function print_image_uploader_script() {
        ?>
        <script>
        jQuery(function($){
            var rlbrmFrame;
            $(document).on('click', '.rlbrm-image-upload', function(e){
                e.preventDefault();
                var $field = $(this).closest('.rlbrm-image-field');
                rlbrmFrame = wp.media({ title: 'Choose Image', button: { text: 'Use Image' }, library: { type: 'image' }, multiple: false });
                rlbrmFrame.off('select').on('select', function(){
                    var a = rlbrmFrame.state().get('selection').first().toJSON();
                    var url = (a.sizes && a.sizes.medium) ? a.sizes.medium.url : a.url;
                    $field.find('.rlbrm-image-id').val(a.id);
                    $field.find('.rlbrm-image-preview').html('<img src="'+url+'" alt="">');
                    $field.find('.rlbrm-image-upload').text('Change Image');
                    $field.find('.rlbrm-image-remove').show();
                });
                rlbrmFrame.open();
            });
            $(document).on('click', '.rlbrm-image-remove', function(e){
                e.preventDefault();
                var $field = $(this).closest('.rlbrm-image-field');
                $field.find('.rlbrm-image-id').val('');
                $field.find('.rlbrm-image-preview').empty();
                $(this).hide();
            });

            function rlbrmGetTags(){
                return ($('#raffle_tags').val() || '').split(',').map(function(s){ return s.trim(); }).filter(function(s){ return s.length; });
            }
            function rlbrmHighlightTagChips(){
                var tags = rlbrmGetTags().map(function(s){ return s.toLowerCase(); });
                $('.rlbrm-tag-chip').each(function(){
                    var t = String($(this).data('tag')).toLowerCase();
                    $(this).toggleClass('button-primary', tags.indexOf(t) !== -1);
                });
            }
            rlbrmHighlightTagChips();
            $(document).on('input', '#raffle_tags', rlbrmHighlightTagChips);
            $(document).on('click', '.rlbrm-tag-chip', function(e){
                e.preventDefault();
                var tag = String($(this).data('tag'));
                var tags = rlbrmGetTags();
                var idx = tags.map(function(s){ return s.toLowerCase(); }).indexOf(tag.toLowerCase());
                if (idx === -1) { tags.push(tag); } else { tags.splice(idx, 1); }
                $('#raffle_tags').val(tags.join(', '));
                rlbrmHighlightTagChips();
            });
        });
        </script>
        <?php
    }

    /* ---------------------------------------------------------------
     * Monitor (single raffle: stats, draw controls, entries, orders)
     * ------------------------------------------------------------- */

    private static function render_monitor($id) {
        global $wpdb;
        $product = wc_get_product($id);

        echo '<div class="wrap rafflelb-rm">';
        self::print_styles();

        if (!$product || get_post_meta($id, self::META_ENABLED, true) !== 'yes') {
            echo '<h1>Raffle not found</h1><p><a href="' . esc_url(admin_url('admin.php?page=' . self::SLUG)) . '">Back to All Raffles</a></p></div>';
            return;
        }

        $view_url = add_query_arg(['page' => self::SLUG, 'action' => 'view', 'id' => $id], admin_url('admin.php'));
        $edit_url = add_query_arg(['page' => self::SLUG, 'action' => 'edit', 'id' => $id], admin_url('admin.php'));

        echo '<h1 class="wp-heading-inline">' . esc_html(get_the_title($id)) . '</h1> ';
        echo '<a href="' . esc_url($edit_url) . '" class="page-title-action">Edit Raffle</a> ';
        echo '<a href="' . esc_url(get_permalink($id)) . '" class="page-title-action" target="_blank" rel="noopener">View on Site</a> ';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline" onsubmit="return confirm(\'Move this raffle to trash?\');">';
        echo '<input type="hidden" name="action" value="rafflelb_rm_trash_raffle">';
        echo '<input type="hidden" name="raffle_id" value="' . esc_attr($id) . '">';
        wp_nonce_field('rafflelb_rm_trash_' . $id);
        echo '<button type="submit" class="page-title-action" style="color:#b42318">Move to Trash</button>';
        echo '</form>';
        echo '<hr class="wp-header-end">';
        echo '<p><a href="' . esc_url(admin_url('admin.php?page=' . self::SLUG)) . '">&larr; Back to All Raffles</a></p>';

        self::render_notices();

        $status = self::draw_status($id);
        $total = absint(get_post_meta($id, self::META_TOTAL, true));
        $claimed = self::claimed($id);
        $price = get_post_meta($id, '_regular_price', true);
        $buy_now_enabled = get_post_meta($id, self::META_BUY_NOW_ENABLED, true) === 'yes';
        $pct = $total > 0 ? min(100, round(($claimed / $total) * 100)) : 0;
        $revenue = $claimed * (float) $price;
        $item_type = get_post_meta($id, self::META_ITEM_TYPE, true);
        $item_type = in_array($item_type, ['tangible', 'digital'], true) ? $item_type : 'tangible';
        $active_holds = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(quantity),0) FROM {$wpdb->prefix}" . self::HOLD_TABLE . " WHERE product_id=%d AND expires_at>=%s",
            $id,
            current_time('mysql')
        ));

        echo '<div class="rlbrm-card"><div class="rlbrm-stats">';
        echo '<div>' . get_the_post_thumbnail($id, [90, 90], ['style' => 'border-radius:8px']) . '</div>';
        echo '<div><strong>Status</strong><br>' . self::status_badge($status) . '</div>';
        echo '<div><strong>Entries</strong><br><span class="rlbrm-bar" style="width:160px"><span style="width:' . esc_attr($pct) . '%"></span></span>' . esc_html($claimed) . ' / ' . esc_html($total) . '</div>';
        echo '<div><strong>Raffle Price</strong><br>' . wp_kses_post(wc_price($price)) . '</div>';
        echo '<div><strong>Entry Revenue</strong><br>' . wp_kses_post(wc_price($revenue)) . '</div>';
        if ($buy_now_enabled) {
            echo '<div><strong>Retail Price</strong><br>' . wp_kses_post(wc_price(get_post_meta($id, self::META_BUY_NOW_PRICE, true))) . '</div>';
        }
        echo '<div><strong>Active Holds</strong><br>' . esc_html($active_holds) . '</div>';
        echo '<div><strong>Delivery Type</strong><br>' . ($item_type === 'digital' ? 'Digital' : 'Tangible (COD eligible)') . '</div>';
        echo '</div></div>';

        ob_start();
        self::render_overview_section($id, $status, $total, $claimed, $price, $revenue, $buy_now_enabled, $item_type, $active_holds);
        $overview_panel = ob_get_clean();

        ob_start();
        if ($status === 'live') {
            self::render_early_close_section($id, $total, $claimed, $view_url);
        } elseif ($status === 'ready_to_draw') {
            self::render_draw_section($id, $view_url);
        }
        $draw_panel = ob_get_clean();

        ob_start();
        if ($status === 'winner_selected') self::render_winner_section($id, $view_url);
        $winner_panel = ob_get_clean();

        ob_start();
        if ($status === 'winner_selected') self::render_fulfillment_section($id, $view_url);
        $fulfillment_panel = ob_get_clean();

        ob_start();
        if ($status === 'winner_selected') self::render_audit_section($id);
        $audit_panel = ob_get_clean();

        ob_start();
        self::render_entries_section($id);
        $entries_panel = ob_get_clean();

        ob_start();
        self::render_orders_section($id, $view_url);
        $orders_panel = ob_get_clean();

        echo '<nav class="rlbrm-workspace-tabs" aria-label="Raffle workspace"><button type="button" class="is-active" data-rlbrm-tab="overview">Overview</button><button type="button" data-rlbrm-tab="entries">Entries</button><button type="button" data-rlbrm-tab="orders">Orders</button><button type="button" data-rlbrm-tab="draw">Draw</button><button type="button" data-rlbrm-tab="winner">Winner</button><button type="button" data-rlbrm-tab="fulfillment">Fulfillment</button><button type="button" data-rlbrm-tab="audit">Audit</button></nav>';
        echo '<section class="rlbrm-workspace-panel is-active" data-rlbrm-panel="overview">' . $overview_panel . '</section>';
        echo '<section class="rlbrm-workspace-panel" data-rlbrm-panel="entries">' . $entries_panel . '</section>';
        echo '<section class="rlbrm-workspace-panel" data-rlbrm-panel="orders">' . $orders_panel . '</section>';
        echo '<section class="rlbrm-workspace-panel" data-rlbrm-panel="draw">' . ($draw_panel ?: '<div class="rlbrm-card">Draw controls are unavailable for this raffle state.</div>') . '</section>';
        echo '<section class="rlbrm-workspace-panel" data-rlbrm-panel="winner">' . ($winner_panel ?: '<div class="rlbrm-card">No winner has been recorded yet.</div>') . '</section>';
        echo '<section class="rlbrm-workspace-panel" data-rlbrm-panel="fulfillment">' . ($fulfillment_panel ?: '<div class="rlbrm-card">Fulfillment becomes available after a winner is recorded.</div>') . '</section>';
        echo '<section class="rlbrm-workspace-panel" data-rlbrm-panel="audit">' . ($audit_panel ?: '<div class="rlbrm-card">Audit details become available after a winner is recorded.</div>') . '</section>';
        echo '<script>(function(){function activate(t){var b=null;document.querySelectorAll(".rlbrm-workspace-tabs button").forEach(function(x){if(x.dataset.rlbrmTab===t)b=x});if(!b)return;document.querySelectorAll(".rlbrm-workspace-tabs button").forEach(function(x){x.classList.toggle("is-active",x===b)});document.querySelectorAll(".rlbrm-workspace-panel").forEach(function(p){p.classList.toggle("is-active",p.dataset.rlbrmPanel===t)})}document.querySelectorAll(".rlbrm-workspace-tabs button").forEach(function(b){b.onclick=function(){activate(b.dataset.rlbrmTab)}});var hash=(window.location.hash||"").replace("#","");if(hash)activate(hash);})();</script>';
        echo '</div>';
    }

    private static function render_overview_section($id, $status, $total, $claimed, $price, $revenue, $buy_now_enabled, $item_type, $active_holds) {
        global $wpdb;
        $available = max(0, $total - $claimed - $active_holds);
        $pct = $total > 0 ? min(100, round(($claimed / $total) * 100)) : 0;
        $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}" . self::RESULT_TABLE . " WHERE product_id=%d LIMIT 1", $id));

        echo '<div class="rlbrm-card rlbrm-overview-card">';
        echo '<div class="rlbrm-overview-head"><div><h2>Overview</h2><p>Current raffle state and live capacity at a glance.</p></div>' . self::status_badge($status) . '</div>';

        echo '<div class="rlbrm-metric-grid">';
        echo '<div><span>Status</span><strong>' . esc_html(self::status_pill_parts($status)[0]) . '</strong></div>';
        echo '<div><span>Entry Price</span><strong>' . wp_kses_post(wc_price($price)) . '</strong></div>';
        echo '<div><span>Claimed</span><strong>' . esc_html($claimed) . '</strong></div>';
        echo '<div><span>Available</span><strong>' . esc_html($available) . '</strong><small>after active holds</small></div>';
        echo '<div><span>Capacity</span><strong>' . esc_html($total) . '</strong></div>';
        echo '<div><span>Active Holds</span><strong>' . esc_html($active_holds) . '</strong><small>reserved, not yet paid</small></div>';
        /* Same current-price x claimed-count figure already shown in the stats
         * bar above (render_monitor's own $revenue) — an operational estimate,
         * not an authoritative accounting total, since it doesn't account for
         * historical price changes. No paid/pending split is derived from it. */
        echo '<div><span>Entry Revenue</span><strong>' . wp_kses_post(wc_price($revenue)) . '</strong><small>estimate at current entry price</small></div>';
        echo '</div>';

        echo '<div class="rlbrm-overview-sections">';

        echo '<section class="rlbrm-overview-section"><h3>Raffle</h3><dl>';
        echo '<div><dt>Prize</dt><dd>' . esc_html(get_the_title($id)) . '</dd></div>';
        echo '<div><dt>Status</dt><dd>' . self::status_badge($status) . '</dd></div>';
        echo '<div><dt>Entry price</dt><dd>' . wp_kses_post(wc_price($price)) . '</dd></div>';
        if ($buy_now_enabled) echo '<div><dt>Retail price</dt><dd>' . wp_kses_post(wc_price(get_post_meta($id, self::META_BUY_NOW_PRICE, true))) . '</dd></div>';
        echo '<div><dt>Capacity</dt><dd>' . esc_html($total) . '</dd></div>';
        echo '<div><dt>Claimed</dt><dd>' . esc_html($claimed) . '</dd></div>';
        echo '<div><dt>Available</dt><dd>' . esc_html($available) . '</dd></div>';
        echo '<div><dt>Delivery type</dt><dd>' . ($item_type === 'digital' ? 'Digital' : 'Tangible') . '</dd></div>';
        echo '<div><dt>Progress</dt><dd><span class="rlbrm-bar" style="width:120px"><span style="width:' . esc_attr($pct) . '%"></span></span>' . esc_html($pct) . '%</dd></div>';
        echo '</dl></section>';

        echo '<section class="rlbrm-overview-section"><h3>Winner</h3>';
        if ($result) {
            $winner_order = wc_get_order(absint($result->order_id));
            $winner_name = self::customer_name(absint($result->user_id), $winner_order);
            echo '<dl>';
            echo '<div><dt>Status</dt><dd>' . self::status_badge('winner_selected') . '</dd></div>';
            echo '<div><dt>Winner</dt><dd>' . esc_html($winner_name) . '</dd></div>';
            echo '<div><dt>Winning entry</dt><dd>#' . esc_html(str_pad((string) $result->entry_number, 3, '0', STR_PAD_LEFT)) . '</dd></div>';
            echo '<div><dt>Selected at</dt><dd>' . esc_html($result->selected_at) . '</dd></div>';
            echo '</dl>';
        } else {
            echo '<p class="rlbrm-no-winner">No winner yet</p>';
        }
        echo '</section>';

        echo '<section class="rlbrm-overview-section"><h3>Fulfillment</h3>';
        if ($result) {
            $fulfillment_status = !empty($result->fulfillment_status) ? $result->fulfillment_status : 'pending';
            echo '<dl>';
            echo '<div><dt>Current state</dt><dd>' . self::fulfillment_badge($fulfillment_status) . '</dd></div>';
            if (!empty($result->fulfilled_at)) echo '<div><dt>Fulfilled at</dt><dd>' . esc_html($result->fulfilled_at) . '</dd></div>';
            echo '</dl>';
        } else {
            echo '<p class="rlbrm-no-winner">Fulfillment becomes available after a winner is recorded.</p>';
        }
        echo '</section>';

        echo '</div>';

        $activity = self::recent_activity($id);
        echo '<section class="rlbrm-overview-section rlbrm-overview-activity"><h3>Recent Activity</h3>';
        if ($activity) {
            echo '<ul class="rlbrm-activity-list">';
            foreach ($activity as $event) {
                $actor = $event->user_id ? get_user_by('id', absint($event->user_id)) : false;
                $label = ucwords(str_replace('_', ' ', (string) $event->event_type));
                echo '<li><span class="rlbrm-activity-event">' . esc_html($label) . '</span> — entry #' . esc_html(str_pad((string) absint($event->entry_number), 3, '0', STR_PAD_LEFT))
                    . ($actor ? ' by ' . esc_html($actor->display_name) : '')
                    . (!empty($event->reason) ? ' (' . esc_html($event->reason) . ')' : '')
                    . '<small>' . esc_html($event->event_at) . '</small></li>';
            }
            echo '</ul>';
        } else {
            echo '<p class="rlbrm-no-winner">No recent activity recorded for this raffle.</p>';
        }
        echo '</section>';

        echo '</div>';
    }

    private static function render_notices() {
        $draw_notice = isset($_GET['rafflelb_draw']) ? sanitize_key(wp_unslash($_GET['rafflelb_draw'])) : '';
        $messages = [
            'success'                => ['success', 'Winner selected and permanently recorded.'],
            'manual_success'         => ['success', 'Manual/external winner recorded and permanently audited.'],
            'early_closed'           => ['success', 'Raffle closed early. New entries are now blocked and the current paid-entry pool is frozen for winner selection.'],
            'early_reason_required'  => ['error', 'Closing a raffle early requires an admin reason.'],
            'early_not_available'    => ['error', 'This raffle cannot be closed early right now.'],
            'already_selected'       => ['warning', 'A winner has already been selected for this raffle.'],
            'manual_reason_required' => ['error', 'Manual winner selection requires a reason or external draw reference.'],
            'manual_entry_invalid'   => ['error', 'The chosen entry is not an active paid entry for this raffle.'],
            'not_ready'              => ['error', 'This raffle is not Ready to Draw.'],
            'pool_mismatch'          => ['error', 'Winner selection was blocked because the eligible paid-entry pool is inconsistent.'],
            'rng_error'              => ['error', 'Secure random selection could not be completed. No winner was recorded.'],
            'save_error'             => ['error', 'The result could not be saved. No winner was recorded.'],
            'invalid'                => ['error', 'Invalid raffle.'],
            'email_sent'             => ['success', 'Winner email sent successfully.'],
            'email_failed'           => ['error', 'Winner email could not be sent.'],
            'email_result_missing'   => ['error', 'Winner result could not be found.'],
            'fulfillment_saved'      => ['success', 'Prize fulfillment status saved.'],
            'fulfillment_missing'    => ['error', 'Prize fulfillment record could not be found.'],
        ];
        if ($draw_notice && isset($messages[$draw_notice])) {
            [$type, $text] = $messages[$draw_notice];
            echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($text) . '</p></div>';
        }

        $order_notice = isset($_GET['rafflelb_order_action']) ? sanitize_key(wp_unslash($_GET['rafflelb_order_action'])) : '';
        $order_messages = [
            'success'            => ['success', 'Entry order updated.'],
            'invalid'            => ['error', 'Invalid order action.'],
            'reason_required'    => ['error', 'A cancellation/refund reason is required.'],
            'order_missing'      => ['error', 'The WooCommerce order could not be found.'],
            'no_active_entries'  => ['warning', 'This order has no active raffle entries to cancel or refund.'],
            'winner_locked'      => ['error', 'Action blocked: this order is attached to a raffle with a selected winner.'],
        ];
        if ($order_notice && isset($order_messages[$order_notice])) {
            [$type, $text] = $order_messages[$order_notice];
            echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($text) . '</p></div>';
        }

        $entry_void_notice = isset($_GET['rafflelb_entry_void']) ? sanitize_key(wp_unslash($_GET['rafflelb_entry_void'])) : '';
        $entry_void_messages = [
            'success'       => ['success', 'Entry voided. The WooCommerce order was not changed.'],
            'invalid'       => ['error', 'Invalid entry void request.'],
            'not_active'    => ['warning', 'That entry is no longer active.'],
            'winner_locked' => ['error', 'Action blocked: this raffle has a permanently selected winner.'],
            'save_error'    => ['error', 'The entry could not be voided. No change was made.'],
        ];
        if ($entry_void_notice && isset($entry_void_messages[$entry_void_notice])) {
            [$type, $text] = $entry_void_messages[$entry_void_notice];
            echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($text) . '</p></div>';
        }
    }

    private static function render_early_close_section($id, $total, $claimed, $view_url) {
        if ($total < 1 || $claimed < 1 || $claimed >= $total) return;

        echo '<div class="rlbrm-card rlbrm-border-amber">';
        echo '<h2>Close Raffle Early</h2>';
        echo '<p class="description">Closing early immediately blocks new entries and freezes the current paid-entry pool for winner selection. A reason is required and recorded in the audit trail.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'Close this raffle early now? New entries will be blocked immediately.\');">';
        echo '<input type="hidden" name="action" value="rafflelb_close_raffle_early">';
        echo '<input type="hidden" name="product_id" value="' . esc_attr($id) . '">';
        echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($view_url) . '">';
        wp_nonce_field('rafflelb_close_raffle_early_' . $id);
        echo '<textarea name="close_reason" rows="2" required placeholder="Required reason for early closure" class="large-text"></textarea>';
        echo '<p><button type="submit" class="button">Close Raffle Early</button></p>';
        echo '</form></div>';
    }

    private static function render_draw_section($id, $view_url) {
        global $wpdb;
        $eligible = $wpdb->get_results($wpdb->prepare(
            "SELECT id, entry_number, order_id, user_id FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d AND status='active' ORDER BY entry_number ASC",
            $id
        ));
        $early_closed = get_post_meta($id, self::META_EARLY_CLOSED, true) === 'yes';
        $early_reason = (string) get_post_meta($id, self::META_EARLY_CLOSE_REASON, true);

        echo '<div class="rlbrm-card rlbrm-border-lime">';
        echo '<h2>Ready to Draw</h2>';
        if ($early_closed && $early_reason !== '') echo '<p><small><strong>Early-close reason:</strong> ' . esc_html($early_reason) . '</small></p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-bottom:16px" onsubmit="return confirm(\'Run the secure random draw now? This result is permanent.\');">';
        echo '<input type="hidden" name="action" value="rafflelb_select_winner">';
        echo '<input type="hidden" name="product_id" value="' . esc_attr($id) . '">';
        echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($view_url) . '">';
        wp_nonce_field('rafflelb_select_winner_' . $id);
        echo '<button type="submit" class="button button-primary">Secure Random Draw</button>';
        echo '</form>';

        echo '<details><summary style="cursor:pointer;font-weight:600">Record Chosen Winner (manual/external)</summary>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:12px" onsubmit="return confirm(\'Record this chosen entry as the winner? This is permanent.\');">';
        echo '<input type="hidden" name="action" value="rafflelb_choose_winner">';
        echo '<input type="hidden" name="product_id" value="' . esc_attr($id) . '">';
        echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($view_url) . '">';
        wp_nonce_field('rafflelb_choose_winner_' . $id);
        echo '<p><label><strong>Choose eligible winning entry</strong><br><select name="entry_number" required class="regular-text"><option value="">Select paid entry…</option>';
        foreach ($eligible as $row) {
            $order = wc_get_order(absint($row->order_id));
            $name = self::customer_name(absint($row->user_id), $order);
            $option = '#' . str_pad((string) absint($row->entry_number), 3, '0', STR_PAD_LEFT) . ' — ' . $name . ' — Order #' . absint($row->order_id);
            echo '<option value="' . esc_attr($row->entry_number) . '">' . esc_html($option) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label><strong>Reason / external draw reference</strong><br><textarea name="selection_note" rows="2" required class="large-text"></textarea></label></p>';
        echo '<button type="submit" class="button">Record Chosen Winner</button>';
        echo '</form></details>';
        echo '</div>';
    }

    private static function render_winner_section($id, $view_url) {
        global $wpdb;
        $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}" . self::RESULT_TABLE . " WHERE product_id=%d LIMIT 1", $id));
        if (!$result) return;

        $order = wc_get_order(absint($result->order_id));
        $name = self::customer_name(absint($result->user_id), $order);
        $method_label = (!empty($result->selection_method) && $result->selection_method === 'manual') ? 'Manual / External' : 'Secure Random';

        echo '<div class="rlbrm-card rlbrm-border-dark">';
        echo '<h2>Winner</h2>';
        echo '<table class="widefat striped"><tbody>';
        echo '<tr><th>Winning Entry</th><td><strong>#' . esc_html(str_pad((string) $result->entry_number, 3, '0', STR_PAD_LEFT)) . '</strong></td></tr>';
        echo '<tr><th>Customer</th><td>' . esc_html($name) . '</td></tr>';
        echo '<tr><th>Order</th><td>' . ($order ? '<a href="' . esc_url($order->get_edit_order_url()) . '">#' . esc_html($result->order_id) . '</a>' : '#' . esc_html($result->order_id)) . '</td></tr>';
        echo '<tr><th>Method</th><td>' . esc_html($method_label) . '</td></tr>';
        echo '<tr><th>Selected At</th><td>' . esc_html($result->selected_at) . '</td></tr>';
        echo '</tbody></table>';

        echo '<h3 style="margin-top:20px">Notification</h3>';
        echo !empty($result->winner_email_sent_at)
            ? '<p><strong style="color:#baff00">Email sent</strong> — ' . esc_html($result->winner_email_sent_at) . '</p>'
            : '<p><strong>Not sent</strong></p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="rafflelb_send_winner_email">';
        echo '<input type="hidden" name="result_id" value="' . esc_attr($result->id) . '">';
        echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($view_url) . '">';
        wp_nonce_field('rafflelb_send_winner_email_' . $result->id);
        echo '<button type="submit" class="button">' . (!empty($result->winner_email_sent_at) ? 'Resend Email' : 'Send Winner Email') . '</button>';
        echo '</form>';
        echo '</div>';
    }

    private static function render_fulfillment_section($id, $view_url) {
        global $wpdb;
        $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}" . self::RESULT_TABLE . " WHERE product_id=%d LIMIT 1", $id));
        if (!$result) return;

        $fulfillment_status = !empty($result->fulfillment_status) ? $result->fulfillment_status : 'pending';
        $is_fulfilled = $fulfillment_status === 'fulfilled';
        $steps = ['pending' => 'Pending', 'contacted' => 'Contacted', 'claimed' => 'Claimed', 'fulfilled' => 'Fulfilled'];
        $step_keys = array_keys($steps);
        $current_index = array_search($fulfillment_status, $step_keys, true);
        if ($current_index === false) $current_index = 0;

        echo '<div class="rlbrm-card rlbrm-border-lime">';
        echo '<h2>Prize Fulfillment</h2>';
        echo '<div class="rlbrm-fulfillment-stepper" aria-label="Fulfillment status">';
        foreach ($steps as $key => $label) {
            $index = array_search($key, $step_keys, true);
            $class = $index < $current_index ? ' is-complete' : ($index === $current_index ? ' is-current' : '');
            echo '<div class="rlbrm-fulfillment-step' . esc_attr($class) . '"><span></span><b>' . esc_html($label) . '</b></div>';
        }
        echo '</div>';

        $lock_id = 'rlbrm-fulfillment-lock-' . absint($result->id);
        if ($is_fulfilled) {
            echo '<p><strong style="color:#baff00">🔒 Prize Fulfilled</strong>';
            if (!empty($result->fulfilled_at)) echo '<br><small>Fulfilled: ' . esc_html($result->fulfilled_at) . '</small>';
            echo '</p>';
            if (!empty($result->fulfillment_note)) echo '<p><small>' . esc_html($result->fulfillment_note) . '</small></p>';
            echo '<div class="rlbrm-fulfillment-lock"><label><input type="checkbox" id="' . esc_attr($lock_id) . '" onchange="this.closest(\'.rlbrm-fulfillment-lock\').nextElementSibling.querySelectorAll(\'select,textarea,button[type=submit]\').forEach(el=>{el.disabled=!this.checked})"> Edit anyway</label></div>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:8px">';
        echo '<input type="hidden" name="action" value="rafflelb_update_fulfillment">';
        echo '<input type="hidden" name="result_id" value="' . esc_attr($result->id) . '">';
        echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($view_url) . '">';
        wp_nonce_field('rafflelb_update_fulfillment_' . $result->id);
        $disabled = $is_fulfilled ? ' disabled' : '';
        echo '<select name="fulfillment_status" class="regular-text"' . $disabled . '>';
        foreach (['pending' => 'Pending', 'contacted' => 'Winner Contacted', 'claimed' => 'Prize Claimed', 'fulfilled' => 'Prize Fulfilled'] as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($fulfillment_status, $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<textarea name="fulfillment_note" rows="2" placeholder="Admin fulfillment note" class="large-text" style="margin-top:6px"' . $disabled . '>' . esc_textarea((string) $result->fulfillment_note) . '</textarea>';
        echo '<p><button type="submit" class="button button-secondary"' . $disabled . '>Save Status</button></p>';
        if (!empty($result->contacted_at)) echo '<p><small>Contacted: ' . esc_html($result->contacted_at) . '</small></p>';
        if (!empty($result->claimed_at)) echo '<p><small>Claimed: ' . esc_html($result->claimed_at) . '</small></p>';
        if (!empty($result->fulfilled_at)) echo '<p><small>Fulfilled: ' . esc_html($result->fulfilled_at) . '</small></p>';
        echo '</form>';
        echo '</div>';
    }

    private static function render_audit_section($id) {
        global $wpdb;
        $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}" . self::RESULT_TABLE . " WHERE product_id=%d LIMIT 1", $id));
        if (!$result) return;

        $method_label = (!empty($result->selection_method) && $result->selection_method === 'manual') ? 'Manual / External' : 'Secure Random';
        $selected_by = !empty($result->selected_by) ? get_user_by('id', absint($result->selected_by)) : false;
        $early_closed = get_post_meta($id, self::META_EARLY_CLOSED, true) === 'yes';
        $early_reason = (string) get_post_meta($id, self::META_EARLY_CLOSE_REASON, true);
        $early_by_id = absint(get_post_meta($id, self::META_EARLY_CLOSED_BY, true));
        $early_by = $early_by_id ? get_user_by('id', $early_by_id) : false;
        $early_claimed = get_post_meta($id, self::META_EARLY_CLOSE_CLAIMED, true);
        $closed_at = (string) get_post_meta($id, self::META_CLOSED_AT, true);

        echo '<div class="rlbrm-card rlbrm-border-dark">';
        echo '<h2>Audit</h2>';
        echo '<table class="widefat striped"><tbody>';
        echo '<tr><th>Winning Entry</th><td><strong>#' . esc_html(str_pad((string) $result->entry_number, 3, '0', STR_PAD_LEFT)) . '</strong></td></tr>';
        echo '<tr><th>Selection Method</th><td>' . esc_html($method_label) . '</td></tr>';
        echo '<tr><th>Selected At</th><td>' . esc_html($result->selected_at) . '</td></tr>';
        echo '<tr><th>Selected By</th><td>' . esc_html($selected_by ? $selected_by->display_name : 'System') . '</td></tr>';
        if (!empty($result->selection_note)) echo '<tr><th>Selection Note</th><td>' . nl2br(esc_html($result->selection_note)) . '</td></tr>';
        echo '<tr><th>Audit Hash</th><td><code class="rlbrm-audit-hash">' . esc_html($result->audit_hash) . '</code></td></tr>';
        if ($early_closed) {
            echo '<tr><th>Early Closed</th><td>Yes</td></tr>';
            if ($closed_at !== '') echo '<tr><th>Closed At</th><td>' . esc_html($closed_at) . '</td></tr>';
            if ($early_reason !== '') echo '<tr><th>Early-close Reason</th><td>' . nl2br(esc_html($early_reason)) . '</td></tr>';
            if ($early_by) echo '<tr><th>Closed By</th><td>' . esc_html($early_by->display_name) . '</td></tr>';
            if ($early_claimed !== '') echo '<tr><th>Claimed At Closure</th><td>' . esc_html($early_claimed) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<p><small>Read-only audit information. No draw or fulfillment actions are available in this tab.</small></p>';
        echo '</div>';
    }

    private static function render_entries_section($id) {
        global $wpdb;
        $search = isset($_GET['rme_s']) ? sanitize_text_field(wp_unslash($_GET['rme_s'])) : '';
        $entry_filter = isset($_GET['rme_filter']) ? sanitize_key(wp_unslash($_GET['rme_filter'])) : 'all';
        if (!in_array($entry_filter, ['all', 'active', 'void'], true)) $entry_filter = 'all';
        $paged = max(1, isset($_GET['rme_paged']) ? absint($_GET['rme_paged']) : 1);
        $per_page = 20;

        $all = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d ORDER BY entry_number ASC",
            $id
        ));

        $active_count = 0;
        $void_count = 0;
        $rows = [];
        foreach ($all as $entry) {
            if ($entry->status === 'active') $active_count++; else $void_count++;
            if ($entry_filter === 'active' && $entry->status !== 'active') continue;
            if ($entry_filter === 'void' && $entry->status === 'active') continue;

            $order = wc_get_order(absint($entry->order_id));
            $name = self::customer_name(absint($entry->user_id), $order);
            $email = $order ? $order->get_billing_email() : '';
            if (!$email && $entry->user_id) {
                $user = get_user_by('id', absint($entry->user_id));
                if ($user) $email = $user->user_email;
            }
            if ($search !== '') {
                $haystack = strtolower($name . ' ' . $email . ' #' . $entry->order_id . ' #' . str_pad((string) $entry->entry_number, 3, '0', STR_PAD_LEFT));
                if (strpos($haystack, strtolower($search)) === false) continue;
            }
            $rows[] = ['entry' => $entry, 'name' => $name, 'email' => $email, 'order' => $order];
        }

        $total = count($rows);
        $total_pages = max(1, (int) ceil($total / $per_page));
        $paged = min($paged, $total_pages);
        $page_rows = array_slice($rows, ($paged - 1) * $per_page, $per_page);

        /* All Entries nav/search/pagination links are built from a base URL that
         * already carries the #entries fragment, so add_query_arg() (which
         * preserves an existing fragment) keeps every one of them on this tab
         * after navigation instead of falling back to Overview. */
        $base_url = add_query_arg(['page' => self::SLUG, 'action' => 'view', 'id' => $id], admin_url('admin.php')) . '#entries';
        $export_url = wp_nonce_url(add_query_arg(['action' => 'rafflelb_rm_export_entries', 'product_id' => $id], admin_url('admin-post.php')), 'rafflelb_rm_export_entries_' . $id);

        echo '<div class="rlbrm-card">';
        echo '<div class="rlbrm-section-head"><h2>Entries (' . esc_html(count($all)) . ')</h2><a class="button" href="' . esc_url($export_url) . '">Export Entries CSV</a></div>';

        echo '<div class="rlbrm-subtoolbar">';
        echo '<nav class="rlbrm-inline-tabs" aria-label="Entry status">';
        foreach (['all' => 'All ' . count($all), 'active' => 'Active ' . $active_count, 'void' => 'Void ' . $void_count] as $key => $label) {
            $url = add_query_arg(array_filter(['rme_filter' => $key === 'all' ? '' : $key, 'rme_s' => $search]), $base_url);
            echo '<a class="' . ($entry_filter === $key ? 'current' : '') . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
        echo '</nav>';
        echo '<form method="get" class="rlbrm-inline-search" action="' . esc_url($base_url) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '"><input type="hidden" name="action" value="view"><input type="hidden" name="id" value="' . esc_attr($id) . '">';
        if ($entry_filter !== 'all') echo '<input type="hidden" name="rme_filter" value="' . esc_attr($entry_filter) . '">';
        echo '<input type="search" name="rme_s" value="' . esc_attr($search) . '" placeholder="Search entry #, customer, email or order #">';
        echo '<button type="submit" class="button">Search</button>';
        if ($search !== '') echo '<a class="button" href="' . esc_url(add_query_arg(array_filter(['rme_filter' => $entry_filter === 'all' ? '' : $entry_filter]), $base_url)) . '">Clear</a>';
        echo '</form>';
        echo '</div>';

        if (!$page_rows) {
            echo '<p>No entries' . ($search !== '' ? ' match this search.' : ' yet.') . '</p>';
        } else {
            $winner_locked = self::draw_status($id) === 'winner_selected';
            echo '<table class="widefat striped"><thead><tr><th>Entry #</th><th>Customer</th><th>Email</th><th>Order #</th><th>Status</th><th>Purchase date</th><th>Action</th></tr></thead><tbody>';
            foreach ($page_rows as $r) {
                $entry = $r['entry'];
                $status_label = $entry->status === 'active' ? 'Confirmed' : 'Void';
                $status_mod = $entry->status === 'active' ? 'active' : 'void';
                echo '<tr>';
                echo '<td>#' . esc_html(str_pad((string) $entry->entry_number, 3, '0', STR_PAD_LEFT)) . '</td>';
                echo '<td>' . esc_html($r['name']) . '</td>';
                echo '<td class="rlbrm-muted">' . esc_html($r['email'] ?: '—') . '</td>';
                echo '<td>' . ($r['order'] ? '<a href="' . esc_url($r['order']->get_edit_order_url()) . '">#' . esc_html($entry->order_id) . '</a>' : '#' . esc_html($entry->order_id)) . '</td>';
                echo '<td><span class="rlbrm-pill rlbrm-pill--' . esc_attr($status_mod) . '">' . esc_html($status_label) . '</span></td>';
                echo '<td class="rlbrm-muted">' . esc_html($entry->created_at) . '</td>';
                echo '<td>';
                if ($entry->status === 'active' && !$winner_locked) {
                    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline" onsubmit="return confirm(\'Void this entry only? Its WooCommerce order and all other entries will remain unchanged.\');">';
                    echo '<input type="hidden" name="action" value="rafflelb_void_entry">';
                    echo '<input type="hidden" name="entry_id" value="' . esc_attr($entry->id) . '">';
                    echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($base_url) . '">';
                    wp_nonce_field('rafflelb_void_entry_' . $entry->id);
                    echo '<button type="submit" class="button button-secondary" style="color:#b42318;border-color:#b42318">Void Entry</button>';
                    echo '</form>';
                } elseif ($entry->status === 'active') {
                    echo '<em>Locked — winner selected</em>';
                } else {
                    echo '<em>—</em>';
                }
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';

            if ($total_pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                for ($p = 1; $p <= $total_pages; $p++) {
                    $url = add_query_arg(array_filter(['rme_filter' => $entry_filter === 'all' ? '' : $entry_filter, 'rme_s' => $search, 'rme_paged' => $p]), $base_url);
                    echo $p === $paged
                        ? '<strong style="padding:4px 9px;border:1px solid #111;border-radius:4px;margin-right:4px">' . esc_html($p) . '</strong>'
                        : '<a class="button" style="margin-right:4px" href="' . esc_url($url) . '">' . esc_html($p) . '</a>';
                }
                echo '</div></div>';
            }
        }
        echo '</div>';
    }

    private static function render_orders_section($id, $view_url) {
        global $wpdb;
        /* Discovery only: a cancelled/refunded order's entries correctly become
         * void, so restricting discovery to status='active' silently drops
         * that order from every list, including the new Cancelled/Failed
         * filter. Read across all historical entries for this raffle instead
         * — this changes nothing about entry status, restores no void entry,
         * and never touches the order itself. */
        $order_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT order_id FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d AND order_id>0 ORDER BY order_id DESC",
            $id
        ));
        if (!$order_ids) return;

        $winner_locked = self::draw_status($id) === 'winner_selected';
        $order_filter = isset($_GET['rmo_filter']) ? sanitize_key(wp_unslash($_GET['rmo_filter'])) : 'all';
        if (!in_array($order_filter, ['all', 'paid', 'pending', 'cancelled'], true)) $order_filter = 'all';
        $paid_statuses = function_exists('wc_get_is_paid_statuses') ? wc_get_is_paid_statuses() : ['processing', 'completed'];

        $orders = [];
        $bucket_counts = ['paid' => 0, 'pending' => 0, 'cancelled' => 0];
        foreach ($order_ids as $order_id) {
            $order = wc_get_order(absint($order_id));
            if (!$order) continue;
            if ($order->has_status($paid_statuses)) { $bucket = 'paid'; }
            elseif ($order->has_status(['cancelled', 'failed', 'refunded'])) { $bucket = 'cancelled'; }
            else { $bucket = 'pending'; }
            $bucket_counts[$bucket]++;
            if ($order_filter !== 'all' && $order_filter !== $bucket) continue;
            $orders[] = ['order' => $order, 'id' => $order_id, 'bucket' => $bucket];
        }

        /* Order filter links are built from a base URL carrying #orders so they
         * stay on this tab after navigation, matching the Entries tab fix. */
        $base_url = add_query_arg(['page' => self::SLUG, 'action' => 'view', 'id' => $id], admin_url('admin.php')) . '#orders';

        echo '<div class="rlbrm-card rlbrm-border-lime">';
        echo '<h2>Orders</h2>';
        echo '<p class="description">Cancelling or refunding an order here voids its active entries for this raffle (RaffleLB VOID protection). A reason is required.</p>';

        echo '<nav class="rlbrm-inline-tabs" aria-label="Order status" style="margin-bottom:12px">';
        foreach (['all' => 'All ' . count($order_ids), 'paid' => 'Paid / Processing ' . $bucket_counts['paid'], 'pending' => 'Pending ' . $bucket_counts['pending'], 'cancelled' => 'Cancelled / Failed ' . $bucket_counts['cancelled']] as $key => $label) {
            $url = add_query_arg(array_filter(['rmo_filter' => $key === 'all' ? '' : $key]), $base_url);
            echo '<a class="' . ($order_filter === $key ? 'current' : '') . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
        echo '</nav>';

        if (!$orders) {
            echo '<p>No orders match this filter.</p></div>';
            return;
        }

        echo '<table class="widefat striped"><thead><tr><th>Order #</th><th>Customer</th><th>Entries</th><th>Amount</th><th>Payment method</th><th>Payment status</th><th>Order status</th><th>Date</th><th>Action</th></tr></thead><tbody>';

        foreach ($orders as $o) {
            $order = $o['order'];
            $order_id = $o['id'];

            /* Active and void counts are calculated separately so a cancelled
             * order with zero active entries never shows a fabricated range. */
            $active_summary = $wpdb->get_row($wpdb->prepare(
                "SELECT MIN(entry_number) first_entry, MAX(entry_number) last_entry, COUNT(*) qty FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d AND order_id=%d AND status='active'",
                $id, $order_id
            ));
            $active_qty = $active_summary ? absint($active_summary->qty) : 0;
            $void_qty = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d AND order_id=%d AND status!='active'",
                $id, $order_id
            ));
            if ($active_qty > 0) {
                $first = '#' . str_pad((string) absint($active_summary->first_entry), 3, '0', STR_PAD_LEFT);
                $last = '#' . str_pad((string) absint($active_summary->last_entry), 3, '0', STR_PAD_LEFT);
                $entries_display = $active_qty . ' (' . ($active_qty > 1 ? $first . '–' . $last : $first) . ')';
                if ($void_qty > 0) $entries_display .= ' <span class="rlbrm-muted">+' . esc_html($void_qty) . ' void</span>';
            } else {
                $entries_display = '<span class="rlbrm-no-winner">0 active</span> <span class="rlbrm-muted">(' . esc_html($void_qty) . ' void)</span>';
            }
            $name = self::customer_name($order->get_user_id(), $order);
            $payment_status = $o['bucket'] === 'paid' ? 'Paid' : ($o['bucket'] === 'cancelled' ? 'Not paid' : 'Pending');

            echo '<tr>';
            echo '<td><a href="' . esc_url($order->get_edit_order_url()) . '">#' . esc_html($order_id) . '</a></td>';
            echo '<td>' . esc_html($name) . '</td>';
            echo '<td>' . wp_kses_post($entries_display) . '</td>';
            echo '<td>' . wp_kses_post($order->get_formatted_order_total()) . '</td>';
            echo '<td class="rlbrm-muted">' . esc_html($order->get_payment_method_title() ?: '—') . '</td>';
            echo '<td><span class="rlbrm-pill rlbrm-pill--' . esc_attr($o['bucket']) . '">' . esc_html($payment_status) . '</span></td>';
            echo '<td class="rlbrm-muted">' . esc_html(wc_get_order_status_name($order->get_status())) . '</td>';
            $created = $order->get_date_created();
            echo '<td class="rlbrm-muted">' . esc_html($created ? wc_format_datetime($created) : '—') . '</td>';
            echo '<td style="min-width:280px"><a class="rlbrm-action rlbrm-action--tertiary" href="' . esc_url($order->get_edit_order_url()) . '">View Order</a><br>';
            if ($winner_locked) {
                echo '<strong style="color:#b42318">Locked — winner selected</strong>';
            } elseif ($order->has_status(['cancelled', 'refunded', 'failed'])) {
                echo '<em>No action available.</em>';
            } else {
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                echo '<input type="hidden" name="action" value="rafflelb_admin_order_action">';
                echo '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">';
                echo '<input type="hidden" name="rafflelb_redirect_to" value="' . esc_attr($view_url) . '">';
                wp_nonce_field('rafflelb_admin_order_action_' . $order_id);
                echo '<select name="raffle_order_action" required style="width:100%;max-width:260px;margin-bottom:6px"><option value="">Choose action…</option><option value="cancel">Cancel Entry Order</option><option value="refund">Mark Order Refunded</option></select>';
                echo '<textarea name="reason" rows="2" required placeholder="Required reason" style="display:block;width:100%;max-width:260px;margin-bottom:6px"></textarea>';
                echo '<button type="submit" class="button button-secondary" onclick="return confirm(\'Apply this order action? Active entries will be voided.\');">Apply Action</button>';
                echo '</form>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    /* ---------------------------------------------------------------
     * Delete
     * ------------------------------------------------------------- */

    /** Read-only CSV export of a raffle's entries. No entries/holds/results are
     *  written; this only reads the same rows Entries already displays. */
    public static function handle_export_entries() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('You are not allowed to export raffle entries.');
        }
        $id = isset($_GET['product_id']) ? absint($_GET['product_id']) : 0;
        if (!$id) wp_die('Invalid raffle.');
        check_admin_referer('rafflelb_rm_export_entries_' . $id);

        global $wpdb;
        $all = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}" . self::ENTRY_TABLE . " WHERE product_id=%d ORDER BY entry_number ASC",
            $id
        ));

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="raffle-' . $id . '-entries-' . gmdate('Y-m-d') . '.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Entry #', 'Customer', 'Email', 'Order #', 'Status', 'Purchase Date']);
        foreach ($all as $entry) {
            $order = wc_get_order(absint($entry->order_id));
            $name = self::customer_name(absint($entry->user_id), $order);
            $email = $order ? $order->get_billing_email() : '';
            if (!$email && $entry->user_id) {
                $user = get_user_by('id', absint($entry->user_id));
                if ($user) $email = $user->user_email;
            }
            fputcsv($out, [
                str_pad((string) absint($entry->entry_number), 3, '0', STR_PAD_LEFT),
                self::csv_safe($name),
                self::csv_safe($email),
                $entry->order_id,
                $entry->status === 'active' ? 'Confirmed' : 'Void',
                $entry->created_at,
            ]);
        }
        fclose($out);
        exit;
    }

    /** Neutralize spreadsheet-formula injection in user-controlled CSV cells.
     *  A leading =, +, -, or @ makes Excel/Sheets evaluate the cell as a
     *  formula; prefixing with a tab keeps the value readable as plain text
     *  without altering the underlying data being exported. */
    private static function csv_safe($value) {
        $value = (string) $value;
        if ($value !== '' && in_array($value[0], ['=', '+', '-', '@'], true)) {
            return "\t" . $value;
        }
        return $value;
    }

    public static function handle_trash() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('You are not allowed to delete raffles.');
        }
        $id = isset($_POST['raffle_id']) ? absint($_POST['raffle_id']) : 0;
        if (!$id) {
            wp_safe_redirect(admin_url('admin.php?page=' . self::SLUG));
            exit;
        }
        check_admin_referer('rafflelb_rm_trash_' . $id);
        wp_trash_post($id);
        wp_safe_redirect(admin_url('admin.php?page=' . self::SLUG . '&rlbrm=trashed'));
        exit;
    }

    /* ---------------------------------------------------------------
     * Reset / Cleanup (danger zone: wipe completed-draw test data)
     * ------------------------------------------------------------- */

    public static function render_reset_page() {
        if (!current_user_can('manage_woocommerce')) return;

        global $wpdb;
        $results_table = $wpdb->prefix . self::RESULT_TABLE;
        $results = $wpdb->get_results("SELECT * FROM {$results_table} ORDER BY selected_at DESC, id DESC");

        echo '<div class="wrap rafflelb-rm">';
        self::print_styles();
        echo '<h1>Reset / Cleanup</h1>';

        $notice = isset($_GET['rlbrm_reset']) ? sanitize_key(wp_unslash($_GET['rlbrm_reset'])) : '';
        if ($notice === 'done') {
            $count = isset($_GET['rlbrm_count']) ? absint($_GET['rlbrm_count']) : 0;
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($count) . ' raffle' . ($count === 1 ? '' : 's') . ' reset. Entries, winner record, and related notifications were permanently deleted; the product' . ($count === 1 ? ' is' : 's are') . ' back to a fresh, unentered raffle.</p></div>';
        } elseif ($notice === 'confirm_mismatch') {
            echo '<div class="notice notice-error is-dismissible"><p>Nothing was reset: the confirmation checkbox must be checked and the typed confirmation text must exactly match.</p></div>';
        } elseif ($notice === 'none_selected') {
            echo '<div class="notice notice-error is-dismissible"><p>Nothing was reset: no raffles were selected.</p></div>';
        }

        $order_notice = isset($_GET['rlbrm_orders']) ? sanitize_key(wp_unslash($_GET['rlbrm_orders'])) : '';
        if ($order_notice === 'done') {
            $orders_deleted = isset($_GET['rlbrm_orders_deleted']) ? absint($_GET['rlbrm_orders_deleted']) : 0;
            $entries_deleted = isset($_GET['rlbrm_entries_deleted']) ? absint($_GET['rlbrm_entries_deleted']) : 0;
            $history_deleted = isset($_GET['rlbrm_history_deleted']) ? absint($_GET['rlbrm_history_deleted']) : 0;
            $results_deleted = isset($_GET['rlbrm_results_deleted']) ? absint($_GET['rlbrm_results_deleted']) : 0;
            echo '<div class="notice notice-success is-dismissible"><p><strong>Test-order cleanup complete.</strong> Permanently deleted ' . esc_html($orders_deleted) . ' WooCommerce order' . ($orders_deleted === 1 ? '' : 's') . ', ' . esc_html($entries_deleted) . ' raffle entr' . ($entries_deleted === 1 ? 'y' : 'ies') . ', ' . esc_html($history_deleted) . ' entry-history row' . ($history_deleted === 1 ? '' : 's') . ', and ' . esc_html($results_deleted) . ' draw-result row' . ($results_deleted === 1 ? '' : 's') . '.</p></div>';
        } elseif ($order_notice === 'confirm_mismatch') {
            echo '<div class="notice notice-error is-dismissible"><p>No orders were deleted: the confirmation checkbox must be checked and the typed confirmation text must exactly match.</p></div>';
        } elseif ($order_notice === 'failed') {
            echo '<div class="notice notice-error is-dismissible"><p>The test-order cleanup could not be completed. No additional cleanup should be attempted until the WooCommerce order system is available.</p></div>';
        }

        echo '<div class="rlbrm-card"><p class="description">This tool is for clearing out test raffles. Selecting a raffle below and confirming will permanently delete its winner record, every paid entry, its entry history, and any related notifications, then reset the product back to a fresh, unentered raffle (full stock, no winner, no early-close flags). WooCommerce orders themselves are never deleted or modified by the raffle-reset tool below.</p></div>';

        // Separate whole-site test-order cleanup. Kept on this page so all destructive
        // maintenance tools live in one clearly marked place.
        $order_count = 0;
        if (function_exists('wc_get_orders')) {
            $count_query = wc_get_orders([
                'limit'    => 1,
                'paginate' => true,
                'return'   => 'ids',
                'type'     => 'shop_order',
                'status'   => array_keys(wc_get_order_statuses()),
            ]);
            if (is_object($count_query) && isset($count_query->total)) {
                $order_count = absint($count_query->total);
            }
        }

        echo '<div class="rlbrm-card rlbrm-border-amber">';
        echo '<h2 style="color:#b42318">&#9888; Danger Zone — Delete All Test Orders &amp; Related Entries</h2>';
        echo '<p><strong>Current WooCommerce orders: ' . esc_html($order_count) . '</strong></p>';
        echo '<p class="description"><strong>This is a whole-site test reset and cannot be undone.</strong> It permanently deletes every WooCommerce customer order, removes RaffleLB paid entries and entry-history rows tied to those orders, removes draw results whose winning order is being deleted, clears the affected winner/draw flags, and recalculates the affected raffle stock. WooCommerce stock reduced by deleted test orders is restored before each order is removed. It does <em>not</em> delete products, customers, coupons, points, or general notifications.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="rafflelb_rm_delete_test_orders">';
        wp_nonce_field('rafflelb_rm_delete_test_orders');
        echo '<p><label><input type="checkbox" name="confirm_delete_orders" value="1" required> I understand this permanently deletes <strong>ALL WooCommerce orders for ALL users</strong> and their related RaffleLB entry data.</label></p>';
        echo '<p><label>Type <code>DELETE ALL TEST ORDERS</code> to confirm:<br><input type="text" name="confirm_orders_text" class="regular-text" autocomplete="off" required></label></p>';
        echo '<p><button type="submit" class="button" style="background:#b42318;border-color:#b42318;color:#fff" onclick="return confirm(\'Permanently delete ALL WooCommerce orders and their related RaffleLB entries? This cannot be undone.\');">Delete All Test Orders &amp; Related Entries</button></p>';
        echo '</form>';
        echo '</div>';

        if (!$results) {
            echo '<div class="rlbrm-card"><p>No completed draws to reset.</p></div></div>';
            return;
        }

        echo '<div class="rlbrm-card rlbrm-border-dark">';
        echo '<h2 style="color:#b42318">&#9888; Danger Zone — Reset Completed Raffles</h2>';
        echo '<p class="description"><strong>This cannot be undone.</strong> Double-check the list below before confirming.</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="rafflelb_rm_reset_winners">';
        wp_nonce_field('rafflelb_rm_reset_winners');

        echo '<table class="widefat striped" style="margin-bottom:16px"><thead><tr><th style="width:32px"><input type="checkbox" id="rlbrm-select-all"></th><th>Raffle</th><th>Winner</th><th>Entries</th><th>Selected At</th><th>Fulfillment</th></tr></thead><tbody>';
        foreach ($results as $result) {
            $pid = absint($result->product_id);
            $order = wc_get_order(absint($result->order_id));
            $winner_name = self::customer_name(absint($result->user_id), $order);
            $entry_count = self::claimed($pid);
            $fulfillment = !empty($result->fulfillment_status) ? $result->fulfillment_status : 'pending';

            echo '<tr>';
            echo '<td><input type="checkbox" name="reset_product_ids[]" value="' . esc_attr($pid) . '" class="rlbrm-reset-checkbox"></td>';
            echo '<td><strong>' . esc_html(get_the_title($pid)) . '</strong></td>';
            echo '<td>' . esc_html($winner_name) . '</td>';
            echo '<td>' . esc_html($entry_count) . '</td>';
            echo '<td>' . esc_html($result->selected_at) . '</td>';
            echo '<td>' . self::fulfillment_badge($fulfillment) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';

        echo '<p><label><input type="checkbox" name="confirm_understand" value="1" required> I understand this permanently deletes all entries, the winner record, and related notifications for the selected raffle(s), and cannot be undone.</label></p>';
        echo '<p><label>Type <code>RESET</code> to confirm:<br><input type="text" name="confirm_text" class="regular-text" autocomplete="off" required></label></p>';
        echo '<p><button type="submit" class="button" style="background:#b42318;border-color:#b42318;color:#fff" onclick="return confirm(\'This permanently deletes the selected raffle data and cannot be undone. Continue?\');">Reset Selected Raffles</button></p>';
        echo '</form>';
        echo '</div>';

        ?>
        <script>
        document.getElementById('rlbrm-select-all').addEventListener('change', function () {
            var checked = this.checked;
            document.querySelectorAll('.rlbrm-reset-checkbox').forEach(function (cb) { cb.checked = checked; });
        });
        </script>
        <?php

        echo '</div>';
    }

    public static function handle_delete_test_orders() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('You are not allowed to delete test orders.');
        }
        check_admin_referer('rafflelb_rm_delete_test_orders');

        $redirect = admin_url('admin.php?page=' . self::SLUG_RESET);
        $confirmed = !empty($_POST['confirm_delete_orders']);
        $confirm_text = isset($_POST['confirm_orders_text']) ? trim(wp_unslash($_POST['confirm_orders_text'])) : '';

        if (!$confirmed || $confirm_text !== 'DELETE ALL TEST ORDERS') {
            wp_safe_redirect(add_query_arg('rlbrm_orders', 'confirm_mismatch', $redirect));
            exit;
        }

        if (!function_exists('wc_get_orders') || !function_exists('wc_get_order')) {
            wp_safe_redirect(add_query_arg('rlbrm_orders', 'failed', $redirect));
            exit;
        }

        global $wpdb;

        $entries_table = $wpdb->prefix . self::ENTRY_TABLE;
        $history_table = $wpdb->prefix . self::HISTORY_TABLE;
        $results_table = $wpdb->prefix . self::RESULT_TABLE;
        $notifications_table = $wpdb->prefix . 'rafflelb_notifications';

        $orders_deleted = 0;
        $entries_deleted = 0;
        $history_deleted = 0;
        $results_deleted = 0;
        $affected_products = [];
        $winner_products = [];
        $failed_order_ids = [];
        $notifications_exist = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $notifications_table)) === $notifications_table);

        // Always query from the first page. Deleting each batch shrinks the result
        // set, so this remains safe for both legacy CPT storage and WooCommerce HPOS.
        do {
            $query_args = [
                'limit'   => 100,
                'return'  => 'ids',
                'type'    => 'shop_order',
                'status'  => array_keys(wc_get_order_statuses()),
                'orderby' => 'ID',
                'order'   => 'ASC',
            ];
            if ($failed_order_ids) {
                $query_args['exclude'] = array_values(array_unique($failed_order_ids));
            }
            $order_ids = wc_get_orders($query_args);

            $order_ids = array_values(array_unique(array_filter(array_map('absint', (array) $order_ids))));
            if (!$order_ids) break;

            foreach ($order_ids as $order_id) {
                // Capture every raffle product touched by this order before deleting
                // the order-specific data, so stock and draw flags can be repaired.
                $entry_product_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT product_id FROM {$entries_table} WHERE order_id=%d",
                    $order_id
                ));
                foreach ((array) $entry_product_ids as $pid) {
                    $pid = absint($pid);
                    if ($pid) $affected_products[$pid] = true;
                }

                $result_product_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT product_id FROM {$results_table} WHERE order_id=%d",
                    $order_id
                ));
                foreach ((array) $result_product_ids as $pid) {
                    $pid = absint($pid);
                    if ($pid) {
                        $affected_products[$pid] = true;
                        $winner_products[$pid] = true;
                    }
                }

                $deleted = $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$entries_table} WHERE order_id=%d",
                    $order_id
                ));
                if ($deleted !== false) $entries_deleted += absint($deleted);

                $deleted = $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$history_table} WHERE order_id=%d",
                    $order_id
                ));
                if ($deleted !== false) $history_deleted += absint($deleted);

                $deleted = $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$results_table} WHERE order_id=%d",
                    $order_id
                ));
                if ($deleted !== false) $results_deleted += absint($deleted);

                $order = wc_get_order($order_id);
                if ($order) {
                    // Restore normal WooCommerce stock first (including direct-purchase
                    // test orders) before permanently removing the order record.
                    if (function_exists('wc_maybe_increase_stock_levels')) {
                        wc_maybe_increase_stock_levels($order_id);
                    }

                    $deleted_order = $order->delete(true);
                    if ($deleted_order !== false && !wc_get_order($order_id)) {
                        $orders_deleted++;
                    } else {
                        // Do not let a single storage/plugin failure trap this cleanup
                        // in an endless first-page loop. Leave the failed order intact.
                        $failed_order_ids[] = $order_id;
                    }
                } else {
                    $failed_order_ids[] = $order_id;
                }
            }
        } while (true);

        // Repair raffle state after the linked orders/entries have gone. Remaining
        // active entries (if any non-order data exists) are respected.
        foreach (array_keys($affected_products) as $pid) {
            $pid = absint($pid);
            if (!$pid) continue;

            // Removing the test orders/entries makes this raffle live/fresh again,
            // even if it had only reached ready-to-draw or was closed early without
            // a permanent winner result yet.
            delete_post_meta($pid, self::META_DRAW_STATUS);
            delete_post_meta($pid, self::META_CLOSED_AT);
            delete_post_meta($pid, self::META_WINNER_ENTRY_ID);
            delete_post_meta($pid, self::META_WINNER_SELECTED_AT);
            delete_post_meta($pid, self::META_EARLY_CLOSED);
            delete_post_meta($pid, self::META_EARLY_CLOSE_REASON);
            delete_post_meta($pid, self::META_EARLY_CLOSED_BY);
            delete_post_meta($pid, self::META_EARLY_CLOSE_CLAIMED);

            if (!empty($winner_products[$pid]) && $notifications_exist) {
                // Winner/draw-complete notifications are no longer valid once that
                // test draw result is removed. General/manual notifications stay.
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$notifications_table} WHERE product_id=%d AND type IN ('winner','draw_completed')",
                    $pid
                ));
            }

            $total = absint(get_post_meta($pid, self::META_TOTAL, true));
            if ($total > 0) {
                $active = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$entries_table} WHERE product_id=%d AND status='active'",
                    $pid
                ));
                $remaining = max(0, $total - $active);

                $product = wc_get_product($pid);
                if ($product && $product->managing_stock()) {
                    $product->set_stock_quantity($remaining);
                    $product->set_stock_status($remaining > 0 ? 'instock' : 'outofstock');
                    $product->save();
                }
            }
        }

        if (function_exists('wc_delete_shop_order_transients')) {
            wc_delete_shop_order_transients();
        }

        wp_safe_redirect(add_query_arg([
            'rlbrm_orders'          => 'done',
            'rlbrm_orders_deleted'  => $orders_deleted,
            'rlbrm_entries_deleted' => $entries_deleted,
            'rlbrm_history_deleted' => $history_deleted,
            'rlbrm_results_deleted' => $results_deleted,
        ], $redirect));
        exit;
    }

    public static function handle_reset_winners() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('You are not allowed to reset raffles.');
        }
        check_admin_referer('rafflelb_rm_reset_winners');

        $redirect = admin_url('admin.php?page=' . self::SLUG_RESET);

        $confirm_understand = !empty($_POST['confirm_understand']);
        $confirm_text = isset($_POST['confirm_text']) ? trim(wp_unslash($_POST['confirm_text'])) : '';
        if (!$confirm_understand || $confirm_text !== 'RESET') {
            wp_safe_redirect(add_query_arg('rlbrm_reset', 'confirm_mismatch', $redirect));
            exit;
        }

        $product_ids = isset($_POST['reset_product_ids']) ? array_map('absint', (array) wp_unslash($_POST['reset_product_ids'])) : [];
        $product_ids = array_values(array_unique(array_filter($product_ids)));
        if (!$product_ids) {
            wp_safe_redirect(add_query_arg('rlbrm_reset', 'none_selected', $redirect));
            exit;
        }

        global $wpdb;
        $results_table = $wpdb->prefix . self::RESULT_TABLE;
        $entries_table = $wpdb->prefix . self::ENTRY_TABLE;
        $history_table = $wpdb->prefix . self::HISTORY_TABLE;
        $holds_table = $wpdb->prefix . self::HOLD_TABLE;
        $notifications_table = $wpdb->prefix . 'rafflelb_notifications';
        $notifications_exist = class_exists('RaffleLB_Notifications');

        $reset_count = 0;
        foreach ($product_ids as $pid) {
            // Only touch raffles that actually have a permanent draw result -
            // this tool resets completed draws, not merely sold-out ones.
            $has_result = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$results_table} WHERE product_id=%d LIMIT 1", $pid));
            if (!$has_result) continue;

            $wpdb->delete($results_table, ['product_id' => $pid], ['%d']);
            $wpdb->delete($entries_table, ['product_id' => $pid], ['%d']);
            $wpdb->delete($history_table, ['product_id' => $pid], ['%d']);
            $wpdb->delete($holds_table, ['product_id' => $pid], ['%d']);

            if ($notifications_exist) {
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$notifications_table} WHERE product_id=%d AND type IN ('winner','draw_completed')",
                    $pid
                ));
            }

            delete_post_meta($pid, self::META_DRAW_STATUS);
            delete_post_meta($pid, self::META_CLOSED_AT);
            delete_post_meta($pid, self::META_WINNER_ENTRY_ID);
            delete_post_meta($pid, self::META_WINNER_SELECTED_AT);
            delete_post_meta($pid, self::META_EARLY_CLOSED);
            delete_post_meta($pid, self::META_EARLY_CLOSE_REASON);
            delete_post_meta($pid, self::META_EARLY_CLOSED_BY);
            delete_post_meta($pid, self::META_EARLY_CLOSE_CLAIMED);

            $product = wc_get_product($pid);
            if ($product) {
                $total = absint(get_post_meta($pid, self::META_TOTAL, true));
                $product->set_stock_quantity($total);
                $product->set_stock_status($total > 0 ? 'instock' : 'outofstock');
                $product->save();
            }

            $reset_count++;
        }

        wp_safe_redirect(add_query_arg(['rlbrm_reset' => 'done', 'rlbrm_count' => $reset_count], $redirect));
        exit;
    }
}

RaffleLB_Raffle_Manager::init();
